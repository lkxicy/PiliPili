<?php
@session_start();

$acc_num=$_POST['acc_num'];
$password=$_POST['password'];
$password1=$_POST['password1'];
$sec_ques=$_POST['sec_ques'];
$user_name=$_POST['user_name'];
$sex=$_POST['sex'];
$img=$_POST['img'];


$flag=1;   //用于判断用户ID是否重复，0为不重复，1为重复，初值为1用于进行循环

if($acc_num==null){
    echo "<script>alert('账号不可为空！');location.href='register.html'</script>";
}

else if($user_name==null){
    echo "<script>alert('用户名不可为空！');location.href='register.html'</script>";
}

else if($sec_ques==null){
    echo "<script>alert('密保问题答案不可为空！');location.href='register.html'</script>";
}

else if($password==null){
    echo "<script>alert('密码不可为空！');location.href='register.html'</script>";
}

else if($password!=$password1){
    echo "<script>alert('两次输入的密码不相同，请重新输入');location.href='register.html'</script>";
}

else if($img==null){
    echo "<script>alert('头像不可为空！');location.href='register.html'</script>";
}

include 'database.php';
get_connection();
$result = mysqli_query($database_connection,"SELECT acc_num,user_name FROM user");
while(@$row = mysqli_fetch_array($result)) {
    if(@$row['acc_num']==$acc_num){
        echo "<script>alert('已存在相同账号，请重新输入');location.href='register.html'</script>";
    }
    else if(@$row['user_name']==$user_name){
        echo "<script>alert('已存在相同用户名，请重新输入');location.href='register.html'</script>";
    }
}

//获取现在数据库中的行数量
$result = mysqli_query($database_connection,"SELECT count(*) FROM user ");
@$row = mysqli_fetch_array($result) ;
$sum=$row[0];

//生成用户ID，顺序叠加
$user_id='bili_'.strval(10000+1+$sum);


mysqli_query($database_connection,"insert into user (user_id,acc_num,password,sec_ques,user_name,sex,img) values ('$user_id','$acc_num','$password','$sec_ques','$user_name','$sex','$img')");

echo "<script>alert('注册成功！');location.href='login.html'</script>";

close_connection();

?>
