<?php
include_once("functions/database.php");
session_start();
$av = $_POST["av"];
$user_id=$_SESSION['user_id'];
//$content = htmlspecialchars(addslashes($_POST["content"]));
$content = addslashes($_POST["review"]);
$currentDate = date("Y-m-d H:i:s");
if($content=="")echo"<script>alert('评论不能为空');location.href='videoPlayer.php?av=$av'</script>";
else {
    $sql = "insert into review values(null,'$user_id','$av','$currentDate','$content')";
    get_connection();
    mysqli_query($database_connection,$sql);
    close_connection();
    echo "<script>alert('评论已发射！');location.href='videoPlayer.php?av=$av'</script>";
}
?>