<?php
@session_start();

$acc_num=$_POST['acc_num'];
$password=$_POST['password'];
$password1=$_POST['password1'];
$sec_ques=$_POST['sec_ques'];

if($acc_num==null){
    echo "<script>alert('账号不可为空！');location.href='forget.html'</script>";
}

else if($password==null){
    echo "<script>alert('密码不可为空！');location.href='forget.html'</script>";
}

else if($password!=$password1){
    echo "<script>alert('两次输入的密码不相同，请重新输入');location.href='forget.html'</script>";
}


include 'database.php';
get_connection();
//查找是否存在这个账号
$result = mysqli_query($database_connection,"SELECT * FROM user where acc_num='$acc_num'");
@$row = mysqli_fetch_array($result);
$sec=$row['sec_ques'];

//不存在这个账号
if($sec==null){
    echo "<script>alert('不存在该账号！');location.href='forget.html'</script>";
}

//存在这个账号但密保问题错误
else if($sec!=null && $sec!=$sec_ques){
    echo "<script>alert('密保问题答案错误！');location.href='forget.html'</script>";
}

//存在这个账号且密保问题正确
else if ($sec==$sec_ques){
    mysqli_query($database_connection,"UPDATE user SET password='$password' WHERE acc_num='$acc_num'");
    echo "<script>alert('重置密码成功！');location.href='login.html'</script>";
}

close_connection();

?>
