<?php
session_start();

@$acc_num=$_SESSION['acc_num'];
@$password=$_SESSION['password'];

include_once ("functions/database.php");
get_connection();

//获取用户名和性别
@$result = mysqli_query($database_connection,"SELECT * FROM user where acc_num='$acc_num' and password='$password'");
@$row = mysqli_fetch_array($result);
@$user_name=$row['user_name'];
@$sex=$row['sex'];
@$img="./img/".$row['img'];

//未登录用户跳转到登录页
if($user_name==null){
    echo "<script>alert('请先登录！');location.href='login.html'</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/register.css" />
    <link rel="stylesheet" href="./css/reset.css">
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/header.css">
    <link rel="stylesheet" href="./css/summary.css">
    <link rel="stylesheet" href="./css/popularize.css">
    <link rel="stylesheet" href="./css/liveStrm.css">
    <link rel="stylesheet" href="./css/animate.css">
    <link rel="stylesheet" href="./css/fanju.css">
    <link rel="stylesheet" href="./css/fjDongTai.css">
    <link rel="stylesheet" href="./css/guoChuang.css">
    <link rel="stylesheet" href="./css/gcyc.css">
    <link rel="stylesheet" href="./css/music.css">
    <link rel="stylesheet" href="./css/talkMusic.css">
    <link rel="stylesheet" href="./css/tbtj.css">
    <link rel="stylesheet" href="./css/footer.css">
    <link rel="stylesheet" href="./css/siderBar.css">
    <title>噼哩噼哩~-pilipili</title>
    <link rel="shortcut icon" href="./img/peach.ico" />
</head>

<script src="./js/setting.js"></script>
<body>
<header>
    <div class="blurBg"></div>
    <nav>
        <div class="nav-wrapper">
            <ul>
                <li>
                    <a href="index.php">主站</a>
                </li>
            </ul>
            <div class="upUser">
                <a href="./center.php">
                    <img src="<?php echo $img; ?>" alt="">
                </a>
                <a style="display: none"> </a>
                <span>
							<a href="upload.php">投稿</a>
						</span>
            </div>
        </div>
    </nav>
    <div class="header-content">
        <a href="index.php">
            <img src="./img/biliLogo.png" alt="">
        </a>
        <div class="rankAndSearch">
            <form action="search.php" type="post">
                <input type="text" name="keyword" placeholder="搜索">
                <input type="submit">
            </form>
        </div>
    </div>
</header>



<div class="title-line">
    <span class="tit" style="font-size: 38px;">修改个人信息</span>
</div>

    <div >
        <form action="setting1.php" method="post"  name="setting" style="height: 400px;">
        <div class="reg-name" style="margin-left: auto; margin-right: auto;margin-top: 60px;">
            昵称：<input type="text" name="user_name" placeholder="你的昵称" style="text-indent:10px;border: 1px solid  #B8C0CC; height: 30px; width: 250px; border-radius: 5px;" value="<?php echo $user_name; ?>">
        </div>

            <?php
            if($sex=='男'){
                echo "<div class=\"reg-sex\" style=\"margin-left: auto; margin-right: auto\">
            性别：&nbsp;<input type=\"radio\" name=\"sex\" value=\"男\" style=\"margin-right: 10px\" checked>男 <input type=\"radio\" name=\"sex\" value=\"女\" style=\"margin-left: 60px; margin-right :10px;\">女
        </div>";
            }
            else if ($sex=='女'){
                echo "<div class=\"reg-sex\" style=\"margin-left: auto; margin-right: auto\">
            性别：&nbsp;<input type=\"radio\" name=\"sex\" value=\"男\" style=\"margin-right: 10px\" >男 <input type=\"radio\" name=\"sex\" value=\"女\" style=\"margin-left: 60px; margin-right :10px;\" checked>女
        </div>";
            }

            ?>


        <div class="reg-sex" style="margin-left: auto; margin-right: auto">
            选择你的头像：<br>
            <img class="image" src="./img/face1.png" id="face1.png" onclick="SelectFace(this)" style="border: white;cursor: pointer;">
            <img class="image" src="./img/face2.png" id="face2.png" onclick="SelectFace(this)" style="border: white;cursor: pointer;">
            <img class="image" src="./img/face3.png" id="face3.png" onclick="SelectFace(this)" style="border: white;cursor: pointer;">
            <img class="image" src="./img/face4.png" id="face4.png" onclick="SelectFace(this)" style="border: white;cursor: pointer;">
            <img class="image" src="./img/face5.png" id="face5.png" onclick="SelectFace(this)" style="border: white;cursor: pointer;">
            <img class="image" src="./img/face6.png" id="face6.png" onclick="SelectFace(this)" style="border: white;cursor: pointer;">
            <img class="image" src="./img/face7.png" id="face7.png" onclick="SelectFace(this)" style="border: white;cursor: pointer;">
            <img class="image" src="./img/face8.png" id="face8.png" onclick="SelectFace(this)" style="border: white;cursor: pointer;">

            <input id="set1" type="hidden" name="img" value="">
        </div>
        </form>


    <div style="text-align: center;">
        <button class="lo-log" onclick="setting.submit()">修改</button>
    </div>
    </div>


</body>
</html>
