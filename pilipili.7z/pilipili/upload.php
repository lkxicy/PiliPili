<?php
session_start();

@$acc_num=$_SESSION['acc_num'];
@$password=$_SESSION['password'];

include 'database.php';
get_connection();

//获取用户名和性别
@$result = mysqli_query($database_connection,"SELECT * FROM user where acc_num='$acc_num' and password='$password'");
@$row = mysqli_fetch_array($result);
@$user_name=$row['user_name'];
@$sex=$row['sex'];
@$img="./img/".$row['img'];

//未登录用户跳转到登录页
if($user_name==null){
    echo "<script>alert('请先登录！');location.href='login.html'</script>";
}
?>

<!DOCTYPE html>
<html>
	<head>
        <script src="./js/upload.js"></script>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" type="text/css" href="./css/center/1.css" />
            <link rel="stylesheet" type="text/css" href="./css/center/2.css" />
            <link rel="stylesheet" type="text/css" href="./css/center/3.css" />
            <link rel="stylesheet" type="text/css" href="./css/center/sum.css" />

            <style type="text/css">
                .lazy-img {
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/img_loading.png) center center no-repeat;
                    width: 100%;
                    height: 100%;
                    display: inline-block;
                }

                .lazy-img img {
                    display: block;
                    width: 100%;
                    height: 100%;
                }

                .lazy-img img[src=''] {
                    opacity: 0;
                }
            </style>
            <style type="text/css">
                .gif-menu .random-p {
                    width: 69px;
                    height: 40px;
                    display: inline-block;
                    vertical-align: top;
                    margin: 3px 0;
                    overflow: hidden;
                }

                .gif-menu .random-p img {
                    width: 100%;
                    height: 100%;
                    margin: 0 auto;
                    border-radius: 3px;
                }
            </style>
            <style type="text/css">
                .primary-menu {
                    position: relative;
                    width: 980px;
                    height: 50px;
                    margin: 0 auto;
                    padding: 8px 0 0 0;
                    margin-bottom: 4px;
                    z-index: 99;
                    border-bottom: 1px solid #fff;
                }

                .primary-menu.border-b {
                    border-bottom: 1px solid #e5e9ef;
                }

                .primary-menu .nav-menu {
                    display: inline-block;
                }

                .primary-menu .nav-menu>li {
                    float: left;
                    display: block;
                    position: relative;
                    margin-right: 0px;
                }

                .primary-menu .nav-menu>li:hover .sub-nav {
                    display: block;
                }

                .primary-menu .nav-menu>li .nav-live {
                    width: 350px;
                    padding: 10px 0;
                }

                .primary-menu .nav-menu>li .nav-live ul {
                    float: left;
                }

                .primary-menu .nav-menu>li .nav-live ul>li {
                    min-width: 100px;
                }

                .primary-menu .nav-menu>li .nav-live .live-field {
                    padding-left: 20px;
                    width: 210px;
                    height: 220px;
                    border-left: 1px solid #e5e9ef;
                    margin: 10px 0;
                }

                .primary-menu .nav-menu>li .nav-live .live-field .pic {
                    display: inline-block;
                    margin-bottom: 20px;
                }

                .primary-menu .nav-menu .channel.on:after {
                    content: '';
                    position: absolute;
                    width: 100%;
                    height: 2px;
                    background: #00a1d6;
                    bottom: -3px;
                    left: 0;
                }

                .primary-menu .nav-menu .channel.on .nav-name {
                    color: #00a1d6;
                }

                .primary-menu .nav-menu>li {
                    width: 46px;
                    text-align: center;
                    display: block;
                }

                .primary-menu .nav-menu>li .nav-name {
                    display: inline-block;
                    vertical-align: middle;
                    color: #222;
                    font-size: 12px;
                    height: 40px;
                    padding-top: 8px;
                    line-height: 50px;
                }

                .primary-menu .nav-menu>li .num-wrap {
                    position: absolute;
                    top: 8px;
                    left: 0;
                    height: 14px;
                    width: 100%;
                    text-align: center;
                }

                .primary-menu .nav-menu>li .num-wrap span {
                    display: inline-block;
                    vertical-align: top;
                    font-size: 12px;
                    transform: scale(0.85);
                    color: #fff;
                    background-color: #ffafc9;
                    border-radius: 3px;
                    height: 12px;
                    line-height: 14px;
                    max-width: 28px;
                    padding: 1px 3px;
                    font-family: sans-serif, sans-serifsans-serif, Calibri, Arial, Helvetica;
                }

                .primary-menu .nav-menu li.home {
                    margin-right: 8px;
                    width: 24px;
                }

                .primary-menu .nav-menu li.home>a {
                    width: auto;
                    display: block;
                    background: url(../../img/icons.png) -660px -1170px no-repeat;
                }

                .primary-menu .nav-menu li.home>a .nav-name {
                    position: relative;
                    top: 15px;
                    line-height: 20px;
                }

                .primary-menu .nav-menu .sub-nav {
                    display: none;
                    position: absolute;
                    left: 0;
                    overflow: hidden;
                    top: 44px;
                    background: #fff;
                    border: 1px solid #e5e9ef \9;
                    border-top: 0;
                    box-shadow: rgba(0, 0, 0, 0.16) 0 2px 4px;
                    border-radius: 0 0 4px 4px;
                    z-index: 2;
                }

                .primary-menu .nav-menu .sub-nav li {
                    position: relative;
                    font-size: 12px;
                    line-height: 20px;
                    min-width: 120px;
                    height: auto;
                    overflow: hidden;
                    text-align: left;
                    transition: 0.2s all;
                }

                .primary-menu .nav-menu .sub-nav li>a {
                    display: block;
                    padding: 5px 15px 5px 25px;
                    margin-right: 10px;
                    background: url(../../img/icons2.png) no-repeat 12px -1613px;
                    white-space: nowrap;
                    transition: 0.2s all;
                    overflow: hidden;
                    position: relative;
                    left: 0;
                    color: #222;
                }

                .primary-menu .nav-menu .sub-nav li>a span {
                    position: relative;
                }

                .primary-menu .nav-menu .sub-nav li>a span:after {
                    content: '';
                    background: url(../../img/icons2.png) no-repeat 0 -1581px;
                    width: 15px;
                    height: 18px;
                    display: block;
                    position: absolute;
                    right: -100px;
                    top: -3px;
                    transition: 0.2s all;
                    opacity: 0;
                }

                .primary-menu .nav-menu .sub-nav li:hover {
                    background-color: #e5e9ef;
                }

                .primary-menu .nav-menu .sub-nav li:hover>a {
                    left: 5px;
                }

                .primary-menu .nav-menu .sub-nav:not(.square-wrap) li:hover>a span:after {
                    right: -21px;
                    opacity: 1;
                }

                .primary-menu .nav-menu .side-nav {
                    margin: 0 3px;
                    width: 40px;
                    text-align: center;
                }

                .primary-menu .nav-menu .side-nav .side-link {
                    display: inline-block;
                    position: relative;
                    overflow: hidden;
                    zoom: 1;
                }

                .primary-menu .nav-menu .side-nav .side-link:hover span {
                    color: #00a1d6;
                }

                .primary-menu .nav-menu .side-nav .side-link i {
                    display: block;
                    width: 18px;
                    height: 18px;
                    margin: 3px auto 2px auto;
                    background: url('../../img/icons.png') no-repeat;
                }

                .primary-menu .nav-menu .side-nav .side-link i.square {
                    background-position: -87px -2006px;
                }

                .primary-menu .nav-menu .side-nav .side-link i.live {
                    background-position: -87px -1878px;
                }

                .primary-menu .nav-menu .side-nav .side-link i.blackroom {
                    background-position: -87px -1942px;
                }

                .primary-menu .nav-menu .side-nav .side-link i.zhuanlan {
                    background-position: -87px -1814px;
                }

                .primary-menu .nav-menu .side-nav .side-link span {
                    display: block;
                    color: #222;
                    margin: 0;
                    font-size: 12px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap {
                    padding-top: 20px;
                    padding-bottom: 20px;
                    white-space: nowrap;
                    width: 387px;
                    height: 188px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap ul {
                    width: 107px;
                    margin-top: -6px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap ul>li {
                    min-width: 107px;
                    margin-top: 8px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap ul>li:first-child {
                    margin-top: 0;
                }

                .primary-menu .nav-menu .side-nav .square-wrap ul>li a {
                    background: none;
                    padding: 2px 10px 2px 18px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .square-field {
                    position: absolute;
                    top: 20px;
                    right: 0;
                    display: block;
                    width: 240px;
                    height: 188px;
                    padding: 0 20px 0 19px;
                    border-left: 1px solid #e5e9ef;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .square-field>div {
                    margin-top: 20px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .square-field>div:first-child {
                    margin-top: 0;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .square-field a {
                    color: #222;
                    line-height: normal;
                    display: block;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .square-field img {
                    width: 240px;
                    height: 84px;
                    border-radius: 4px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .icon-prim {
                    width: 16px;
                    height: 13px;
                    margin-right: 4px;
                    margin-top: 4px;
                    vertical-align: top;
                    display: inline-block;
                    background-image: url(../../img/icons.png);
                }

                .primary-menu .nav-menu .side-nav .square-wrap .icon-activity {
                    background-position: -280px -1179px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .icon-game {
                    background-position: -279px -1241px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .icon-news {
                    background-position: -344px -1178px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .icon-hy {
                    background-position: -280px -1370px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .icon-mango {
                    background-position: -280px -1433px;
                }

                .primary-menu .nav-menu .side-nav .square-wrap .icon-vip-buy {
                    display: inline-block;
                    width: 16px;
                    height: 13px;
                    margin-top: 0;
                    vertical-align: inherit;
                    background-repeat: no-repeat;
                    background-image: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/icon-pc.png);
                    background-position: center;
                }

                .nav-gif {
                    position: absolute;
                    right: 0;
                    top: 0;
                    height: 50px;
                    padding: 4px 0;
                }

                @media screen and (min-width: 1400px) {
                    .primary-menu {
                        width: 1160px;
                    }

                    .primary-menu .nav-menu>li {
                        width: 48px;
                        margin-right: 8px;
                    }

                    .primary-menu .nav-menu>li.side-nav {
                        margin: 0 5px;
                    }

                    .primary-menu .nav-menu>li.home {
                        margin-right: 14px;
                    }

                    .primary-menu .nav-menu>li.home a {
                        width: 24px;
                    }
                }
            </style>

            <style type="text/css">
                @keyframes tiaobi {
                    0% {
                        top: 0px;
                        opacity: 0;
                    }

                    50% {
                        top: -40px;
                        transform: rotateY(-360deg);
                        opacity: 1;
                    }

                    100% {
                        top: 0px;
                        transform: rotateY(0deg);
                        opacity: 0;
                    }
                }

                @keyframes num-tipdown {
                    33% {
                        top: -3px;
                        opacity: 1;
                    }

                    66% {
                        top: -3px;
                        opacity: 1;
                    }

                    100% {
                        top: -3px;
                        opacity: 0;
                    }
                }

                @keyframes num {
                    100% {
                        transform: translateY(10px);
                        opacity: 0;
                    }
                }

                @keyframes num-move {
                    100% {
                        top: 3px;
                        opacity: 1;
                    }
                }

                .bili-header-m .profile-m {
                    left: 50%;
                    margin-left: -130px;
                    width: 260px;
                    padding: 50px 0 0 0;
                    top: 42px;
                    background: #fff;
                    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    border-radius: 0 0 4px 4px;
                    line-height: normal;
                }

                .bili-header-m .profile-m .big-vip-red {
                    color: #fb7299 !important;
                }

                .bili-header-m .profile-m .small-vip-green.year {
                    color: #62c076 !important;
                }

                .bili-header-m .profile-m .header-u-info a {
                    color: #222;
                }

                .bili-header-m .profile-m .header-uname {
                    padding-bottom: 15px;
                }

                .bili-header-m .profile-m .header-uname b {
                    display: block;
                    margin-bottom: 8px;
                }

                .bili-header-m .profile-m .header-uname .vip-type span {
                    padding: 2px 3px;
                    background: #fb7299;
                    color: #fff !important;
                    border-radius: 3px;
                }

                .bili-header-m .profile-m .header-uname .vip-type span.small-vip-green {
                    background: #62c076;
                }

                .bili-header-m .profile-m .btns-profile {
                    position: relative;
                    margin: 0 20px;
                }

                .bili-header-m .profile-m .btns-profile .bili-icon {
                    display: inline-block;
                    width: 18px;
                    height: 18px;
                    vertical-align: middle;
                    background-repeat: no-repeat;
                }

                .bili-header-m .profile-m .btns-profile .num {
                    vertical-align: middle;
                    display: inline-block;
                    transition: 2s;
                }

                .bili-header-m .profile-m .btns-profile .num-move {
                    position: absolute;
                    transition: 2s;
                    left: 23px;
                    top: -10px;
                    opacity: 0;
                    line-height: 14px;
                }

                .bili-header-m .profile-m .btns-profile .num-tip {
                    color: #2CC06F;
                    position: absolute;
                    transition: 0.3s;
                    left: 60px;
                    top: -18px;
                    opacity: 0;
                    background: #fff;
                    padding: 3px 5px;
                    z-index: 10;
                }

                .bili-header-m .profile-m .btns-profile .coin .bi {
                    background-position: -343px -471px;
                    margin-right: 2px;
                    position: relative;
                    z-index: 2;
                }

                .bili-header-m .profile-m .btns-profile .coin .jia {
                    z-index: 1;
                    left: 0px;
                    position: absolute;
                    top: 0;
                    width: 18px;
                    height: 18px;
                    background-position: -279px -1495px;
                }

                .bili-header-m .profile-m .btns-profile .tracker .jia {
                    animation: tiaobi 1s ease-in-out 0s 1 alternate forwards;
                }

                .bili-header-m .profile-m .btns-profile .tracker .num {
                    animation: num 0.5s ease-in-out 0s 1 alternate forwards;
                }

                .bili-header-m .profile-m .btns-profile .tracker .num-move {
                    animation: num-move 0.5s ease-in-out 0s 1 alternate forwards;
                }

                .bili-header-m .profile-m .btns-profile .tracker .num-tip {
                    animation: num-tipdown 2s ease-in-out 0s 1 alternate forwards;
                }

                .bili-header-m .profile-m .btns-profile .currency {
                    position: absolute;
                    left: 58px;
                    z-index: 0;
                }

                .bili-header-m .profile-m .btns-profile .currency .bili-icon {
                    background-position: -407px -471px;
                    margin: 0 5px 0 8px;
                }

                .bili-header-m .profile-m .btns-profile .ver {
                    position: relative;
                }

                .bili-header-m .profile-m .btns-profile .ver a {
                    display: block;
                }

                .bili-header-m .profile-m .btns-profile .ver .bili-icon:before {
                    content: "";
                    position: absolute;
                    display: none;
                    top: -3px;
                    right: -3px;
                    width: 7px;
                    height: 7px;
                    background-color: #F25D8E;
                    border: 2px solid #fff;
                    border-radius: 50%;
                }

                .bili-header-m .profile-m .btns-profile .ver .tips {
                    display: none;
                    padding: 0 6px;
                    height: 20px;
                    line-height: 20px;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    position: absolute;
                    right: 30px;
                    top: -2px;
                    white-space: nowrap;
                    background-color: #fff;
                    color: #222;
                    z-index: 10;
                }

                .bili-header-m .profile-m .btns-profile .ver .tips:after {
                    content: "";
                    position: absolute;
                    width: 8px;
                    height: 8px;
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/arrow4.png);
                    right: -8px;
                    top: 6px;
                }

                .bili-header-m .profile-m .btns-profile .ver:hover .tips {
                    display: block;
                }

                .bili-header-m .profile-m .btns-profile .email {
                    margin-right: 10px;
                }

                .bili-header-m .profile-m .btns-profile .email .bili-icon {
                    background-position: -279px -534px;
                }

                .bili-header-m .profile-m .btns-profile .email .bili-icon:before {
                    display: block;
                }

                .bili-header-m .profile-m .btns-profile .email.verified .bili-icon {
                    background-position: -343px -534px;
                }

                .bili-header-m .profile-m .btns-profile .email.verified .bili-icon:before {
                    display: none;
                }

                .bili-header-m .profile-m .btns-profile .phone .bili-icon {
                    background-position: -279px -599px;
                }

                .bili-header-m .profile-m .btns-profile .phone .bili-icon:before {
                    display: block;
                }

                .bili-header-m .profile-m .btns-profile .phone.verified .bili-icon {
                    background-position: -343px -599px;
                }

                .bili-header-m .profile-m .btns-profile .phone.verified .bili-icon:before {
                    display: none;
                }

                .bili-header-m .profile-m .btns-profile .link-to-bind-mobile {
                    position: absolute;
                    right: 0;
                    bottom: -20px;
                }

                .bili-header-m .profile-m .btns-profile .link-to-bind-mobile a {
                    color: #00a1d6;
                    white-space: nowrap;
                }

                .bili-header-m .profile-m .btns-profile .link-to-bind-mobile a:hover {
                    color: #f25d8e;
                }

                .bili-header-m .profile-m .grade {
                    position: relative;
                    margin: 24px 0 30px 0;
                    padding: 0 20px;
                }

                .bili-header-m .profile-m .grade .bar {
                    position: relative;
                    top: 6px;
                    width: 170px;
                    height: 8px;
                    background: #eee;
                }

                .bili-header-m .profile-m .grade .bar .lt {
                    width: 18px;
                    height: 18px;
                    border-radius: 9px;
                    position: absolute;
                    left: -17px;
                    top: -6px;
                    color: #fff;
                    font-size: 12px;
                    line-height: 18px;
                    text-align: center;
                    background-color: #f3cb85;
                    background-image: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/grade_icon.png);
                    background-repeat: no-repeat;
                }

                .bili-header-m .profile-m .grade .bar .lt.lv0 {
                    background-position: -153px -8px;
                    background-color: #ccc;
                }

                .bili-header-m .profile-m .grade .bar .lt.lv1 {
                    background-position: -153px -44px;
                }

                .bili-header-m .profile-m .grade .bar .lt.lv2 {
                    background-position: -153px -80px;
                }

                .bili-header-m .profile-m .grade .bar .lt.lv3 {
                    background-position: -153px -116px;
                }

                .bili-header-m .profile-m .grade .bar .lt.lv4 {
                    background-position: -153px -152px;
                }

                .bili-header-m .profile-m .grade .bar .lt.lv5 {
                    background-position: -153px -188px;
                }

                .bili-header-m .profile-m .grade .bar .lt.lv6 {
                    background-position: -153px -224px;
                }

                .bili-header-m .profile-m .grade .bar .rate {
                    height: 8px;
                    background-color: #f3cb85;
                    width: 20%;
                }

                .bili-header-m .profile-m .grade .bar .num {
                    position: absolute;
                    right: 0;
                    bottom: -24px;
                    white-space: nowrap;
                }

                .bili-header-m .profile-m .grade .bar .num span {
                    color: #ccc;
                }

                .bili-header-m .profile-m .grade .bar .num .v0 {
                    color: #00a1d6;
                    white-space: nowrap;
                }

                .bili-header-m .profile-m .grade .bar .num .v0:hover {
                    color: #f25d8e;
                }

                .bili-header-m .profile-m .grade:hover .desc-tips {
                    display: block;
                }

                .bili-header-m .profile-m .grade .desc-tips {
                    display: none;
                    padding: 15px 15px 15px 20px;
                    position: absolute;
                    top: -16px;
                    left: 260px;
                    border-radius: 2px;
                    background-color: #fff;
                    z-index: 100;
                    width: 220px;
                    line-height: 24px;
                    word-break: break-word;
                    word-wrap: break-word;
                    min-height: 65px;
                    color: #676b73;
                    box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.25);
                    text-align: left;
                }

                .bili-header-m .profile-m .grade .desc-tips .arrow-left {
                    position: absolute;
                    display: inline-block;
                    top: 16px;
                    left: -10px;
                    width: 10px;
                    height: 20px;
                    background: transparent url(//s1.hdslb.com/bfs/seed/jinkela/header/images/grade_icon.png) -182px -224px no-repeat;
                }

                .bili-header-m .profile-m .grade .desc-tips .lv-row {
                    margin-bottom: 10px;
                }

                .bili-header-m .profile-m .grade .desc-tips .lv-row strong {
                    font-size: 14px;
                    color: #222222;
                    padding: 0 3px;
                }

                .bili-header-m .profile-m .grade .desc-tips .help-link {
                    margin-top: 15px;
                    float: right;
                    color: #00a1d6;
                }

                .bili-header-m .profile-m .member-menu {
                    border-top: 1px solid #e5e9ef;
                    padding: 10px 20px 40px 20px;
                }

                .bili-header-m .profile-m .member-menu ul {
                    width: 240px;
                    clear: both;
                    zoom: 1;
                }

                .bili-header-m .profile-m .member-menu li {
                    float: left;
                    width: 100px;
                    margin-right: 20px;
                    position: relative;
                }

                .bili-header-m .profile-m .member-menu li a {
                    white-space: nowrap;
                    color: #222222;
                    text-align: left;
                    margin: 0 auto;
                    display: block;
                    padding: 5px 0 5px 0;
                    line-height: 16px;
                }

                .bili-header-m .profile-m .member-menu li a:hover {
                    color: #00a1d6;
                }

                .bili-header-m .profile-m .member-menu li a:hover .bili-icon.b-icon-p-account {
                    background-position: -536px -407px;
                }

                .bili-header-m .profile-m .member-menu li a:hover .bili-icon.b-icon-p-member {
                    background-position: -601px -1046px;
                }

                .bili-header-m .profile-m .member-menu li a:hover .bili-icon.b-icon-p-wallet {
                    background-position: -536px -472px;
                }

                .bili-header-m .profile-m .member-menu li a:hover .bili-icon.b-icon-p-live {
                    background-position: -537px -855px;
                }

                .bili-header-m .profile-m .member-menu li a:hover .bili-icon.b-icon-p-ticket {
                    background-position: -2px -15px;
                }

                .bili-header-m .profile-m .member-menu li a:hover .bili-icon.b-icon-p-cheese {
                    background-position: 0 -18px;
                }

                .bili-header-m .profile-m .member-menu li a:hover .bili-icon.b-icon-p-shopCenter {
                    background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAARCAYAAAACCvahAAAAAXNSR0IArs4c6QAAAcpJREFUOBGlk7tLY0EUxr+ZRBcEjY8tFRHEZyFbrpXb+g8sqyZiZ2en9mKjjYWFhQhJFMVCN4q7oPgABZtd0MYJUVESxEaFaOEj3jt+k+vdJIpZwQMzc2fO9ztnzswd4AMm0mxQfYXANL9roLWzZhxC6LQ/p9NxaPED3Y27AvPag1ulKByEv2ExB8gO5AaYVu2EJ/DZWytxF+sgcIZA40IOaMQm88vmb1qhZw+XKb8E7F5IOeIGfuc4zuw9hPEFhUVb74SeZWU7gG6RPKAk7m9K/8Gb2ovFk8zcOH4dfqLOJHJMXJWwpmuBkJrhFiwIewRCVlI0Co1qSD0Mu2AVItVKYoiaBG+knxnPOA5wLnjaxz7cPexz4YpgHB7MwdZ/ANkHG3UMeAotJyCsWp5PJzMyK9qQEj5nG0G1gZnoN2fyn95cX0jZRpWpw2VCah2m7pcWOphEUNVlL7+GoZeRUFOIRIvTQhMoHO1jjeX8q2L54UDTGOBZQ1IvcXt/EY9uE6hAc8P3bNB8v96eWQ3Uh9mbltccWGgLFgrzKl3n7yPqqKc9wyLCawnzQM5dzZvjRcrH+n8af+b5zR5VQT+WvQm5Dgv36KqPmQfzBCHdoDvCRYX+AAAAAElFTkSuQmCC");
                }

                .bili-header-m .profile-m .member-menu li a .bili-icon {
                    width: 16px;
                    height: 16px;
                    margin-right: 10px;
                    vertical-align: top;
                }

                .bili-header-m .profile-m .member-menu li a .bili-icon.b-icon-p-account {
                    background-position: -472px -407px;
                }

                .bili-header-m .profile-m .member-menu li a .bili-icon.b-icon-p-member {
                    background-position: -536px -1046px;
                }

                .bili-header-m .profile-m .member-menu li a .bili-icon.b-icon-p-wallet {
                    background-position: -472px -472px;
                }

                .bili-header-m .profile-m .member-menu li a .bili-icon.b-icon-p-live {
                    background-position: -473px -855px;
                }

                .bili-header-m .profile-m .member-menu li a .bili-icon.b-icon-p-ticket {
                    width: 18px;
                    height: 15px;
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/icon-ticket.png) -2px 0;
                }

                .bili-header-m .profile-m .member-menu li a .bili-icon.b-icon-p-cheese {
                    width: 16px;
                    height: 16px;
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/icon-cheese.png) 0 0;
                }

                .bili-header-m .profile-m .member-menu li a .bili-icon.b-icon-p-shopCenter {
                    width: 15px;
                    height: 17px;
                    vertical-align: bottom;
                    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAARCAYAAAACCvahAAAAAXNSR0IArs4c6QAAAghJREFUOBGlU89rE0EUfm92kyLFtDUFESpFyFERj3pSPAj+A6LgwZtKsi3Crs0GYSGkaVaQkPXgQbxULzn4Ey+KIrTgJUJ7EupFGoo9tFYLBmp35vkmzS5LC8nBheHN++b73o95OwD/8aHWThfvnQ1l+BQITrDbxXoxqWcTBldN07har5Y/Y7PZNBZaS18BaKZRm32BiLGAiJKBugGsmdJlIHoEE8dyYrG1fI1Ja4FffZ4Uaqb296+gNvuWoy9he/26IKCbINBP1DVwayA+5JpuCC7hTOro+KeBigQhNT62yLrTnBl+08bGaHTmeZ457Xmxr/FCozHEuIg44dZWhnvaxrztPhOIEkzyQYkJkuo+IE1yxxUQxjskeU4Rlbn7thDgkAFralfd5btAczibuf3n5/YyhnQSSK2iMCoh7rYMJaaAwjkg/J4W5kUJKqck3eJxZjjw+UPZ0ZFuJQXH/Wg57oWorH5Wjy9vF5XmmPuJBbv4ITs8dIl7DJNnllN6bBopPZVvER5fQgQAijebnZ0njlM7rDF9gZbtTnHfRx5UvZWYx5sD4sCv1BHE+w79ep133C+bnb8L/MNmT+UmrySFen+gbA02/Mo8G736fnuZiSQipPsye4dWEKR5SlK7e5lRvOKe5gu2+2NQAGqvj3Cil5oXv5o7pdJxSTQ2SAyh2KnXyiv6wfwDzdPIibxpJGgAAAAASUVORK5CYII=);
                }

                .bili-header-m .profile-m .member-bottom {
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    height: 30px;
                    line-height: 30px;
                    background-color: #f4f5f7;
                    border-radius: 0 0 4px 4px;
                }

                .bili-header-m .profile-m .member-bottom .logout {
                    float: right;
                    padding-right: 20px;
                    color: #222;
                }

                .bili-header-m .profile-m .member-bottom .logout:hover {
                    color: #00a1d6;
                }
            </style>

            <style type="text/css">
                .bili-header-m.vip-m {
                    width: 260px;
                    margin-left: -107px;
                    position: absolute;
                    border-radius: 0 0 4px 4px;
                    background-color: #fff;
                    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    border: 1px solid #e5e9ef;
                    text-align: left;
                    font-size: 0;
                    z-index: 7000;
                }

                .bili-header-m .bubble-traditional {
                    padding: 14px;
                }

                .bili-header-m .bubble-traditional .recommand .title {
                    color: #212121;
                    font-size: 14px;
                    margin: 5px 0 12px;
                    font-weight: 900;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col .item {
                    display: inline-block;
                    margin-bottom: 7px;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col .item .pic {
                    display: inline-block;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col .item img {
                    border-radius: 4px;
                    background: #ccc;
                    display: block;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col .item .recommand-link {
                    display: block;
                    margin-top: 10px;
                    font-size: 12px;
                    color: #222222;
                    text-align: left;
                    line-height: 18px;
                    height: 36px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    -webkit-line-clamp: 2;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col .item .recommand-link:hover {
                    color: #fb7299;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-1 .item {
                    width: 100%;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-1 img {
                    width: 230px;
                    height: 68px;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-2 .item {
                    width: 50%;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-2 .item:nth-child(2) {
                    text-align: right;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-2 .item:nth-child(2) .recommand-link {
                    margin-left: 8px;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-2 img {
                    width: 107px;
                    height: 143px;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-3 .item {
                    width: 33%;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-3 .item:nth-child(2) {
                    text-align: center;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-3 .item:nth-child(2) .recommand-link {
                    margin-left: 3px;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-3 .item:nth-child(3) {
                    text-align: right;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-3 .item:nth-child(3) .recommand-link {
                    margin-left: 4px;
                }

                .bili-header-m .bubble-traditional .recommand .bubble-col.bubble-col-3 img {
                    width: 72px;
                    height: 94px;
                }

                .bili-header-m .bubble-traditional .notify {
                    border-top: 1px solid #f0f0f0;
                    padding: 11px 0 4px 0;
                }

                .bili-header-m .bubble-traditional .notify .notify-list {
                    font-size: 12px;
                }

                .bili-header-m .bubble-traditional .notify .notify-list li {
                    margin-top: 18px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .bili-header-m .bubble-traditional .notify .notify-list li:first-child {
                    margin-top: 0;
                }

                .bili-header-m .bubble-traditional .notify .notify-list li a {
                    color: #222;
                }

                .bili-header-m .bubble-traditional .notify .notify-list li a:hover {
                    color: #fb7299;
                }

                .bili-header-m .bubble-traditional .notify .notify-list li .icon {
                    color: #fb7299;
                    border: 1px solid #fb7299;
                    width: 32px;
                    height: 16px;
                    line-height: 16px;
                    border-radius: 3px;
                    text-align: center;
                    display: inline-block;
                    box-sizing: border-box;
                    margin-right: 6px;
                }

                .bili-header-m .bubble-traditional .renew-btn {
                    margin-top: 20px;
                    text-align: center;
                    position: relative;
                }

                .bili-header-m .bubble-traditional .renew-btn button {
                    width: 160px;
                    height: 32px;
                    background: #00a1d6;
                    color: #fff;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                }

                .bili-header-m .bubble-traditional .renew-btn button:hover {
                    background: #00b5e5;
                }

                .bili-header-m .bubble-traditional .renew-btn .cash {
                    position: absolute;
                    right: 25px;
                    top: -10px;
                    display: inline-block;
                    width: 44px;
                    height: 16px;
                    font-size: 12px;
                    line-height: 16px;
                    background: #f25d8e;
                    color: #fff;
                    border: 2px solid #fff;
                    border-radius: 10px;
                }
            </style>

            <style type="text/css">
                .bili-header-m .mini-wnd-nav.later-wnd {
                    left: -126px;
                }

                .bili-header-m .mini-wnd-nav.later-wnd .read-more-grp {
                    padding: 4px 12px 12px;
                }

                .bili-header-m .mini-wnd-nav.later-wnd .read-more {
                    width: 140px;
                    margin: 0;
                    float: left;
                }

                .bili-header-m .mini-wnd-nav.later-wnd .mr {
                    margin-right: 12px;
                }
            </style>

            <style type="text/css">
                .bili-header-m .mini-wnd-nav.favorite-wnd {
                    left: -157px;
                }
            </style>

            <style type="text/css">
                .bili-header-m .mini-wnd-nav.history-wnd {
                    width: 400px;
                    left: auto;
                    right: -58px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .split {
                    margin: 0 5px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .link {
                    max-width: 240px;
                    float: left;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .top-login .txt {
                    font-size: 14px;
                    color: #222;
                    width: 215px;
                    margin: 0 auto 12px;
                    line-height: normal;
                    text-align: center;
                    padding-top: 28px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .top-login .loginbtn {
                    font-size: 12px;
                    color: #fff;
                    line-height: normal;
                    text-align: left;
                    background-color: #00a1d6;
                    padding: 5px 11px;
                    border-radius: 4px;
                    margin: 10px 63px 20px;
                    position: relative;
                    z-index: 201;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .top-login .loginbtn:hover {
                    background-color: #00b5e5;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .top-open-history .txt {
                    font-size: 12px;
                    color: #222;
                    line-height: normal;
                    text-align: center;
                    padding-top: 20px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .top-open-history .openbtn {
                    font-size: 12px;
                    color: #fff;
                    line-height: normal;
                    text-align: left;
                    background-color: #00a1d6;
                    padding: 6.5px 11px;
                    border-radius: 4px;
                    position: relative;
                    z-index: 201;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .top-open-history .openbtn:hover {
                    background-color: #00b5e5;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .state {
                    font-size: 12px;
                    color: #99a2aa;
                    float: right;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .state .device {
                    width: 20px;
                    height: 20px;
                    background: url(../../img/icons.png) no-repeat;
                    margin-left: 9px;
                    margin-top: 3px;
                    display: inline-block;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .state .device.pc {
                    background-position: -1367px -406px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .state .device.phone {
                    background-position: -1367px -466px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .state .device.pad {
                    background-position: -1367px -526px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .state .device.tv {
                    background-position: -1430px -472px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .state .device.unknown {
                    background-position: -1430px -407px;
                }

                .bili-header-m .mini-wnd-nav.history-wnd .state span,
                .bili-header-m .mini-wnd-nav.history-wnd .state .history-wnd .state .device {
                    display: inline-block;
                    float: left;
                }
            </style>

            <style type="text/css">
                .bili-header-m .i_menu_login {
                    background: #fff;
                    left: 50%;
                    margin-left: -130px;
                    width: 260px;
                    padding-bottom: 0;
                    padding-top: 50px;
                    border-top: none;
                    width: 320px;
                    margin-left: -160px;
                    padding: 12px;
                    text-align: left;
                    line-height: normal;
                    border: 1px solid #e5e9ef;
                }

                .bili-header-m .i_menu_login .tip {
                    font-size: 12px;
                    color: #6d757a;
                }

                .bili-header-m .i_menu_login .img {
                    width: 320px;
                    height: 200px;
                    margin: 12px 0;
                    overflow: hidden;
                    position: relative;
                    background: url(//static.hdslb.com/images/base/danmu.png) no-repeat center;
                }

                .bili-header-m .i_menu_login .img img {
                    width: 320px;
                    height: 200px;
                    position: absolute;
                    top: 0;
                    left: 0;
                }

                .bili-header-m .i_menu_login .login-btn {
                    display: block;
                    height: 43px;
                    line-height: 43px;
                    text-align: center;
                    background: #00a1d6;
                    border-radius: 4px;
                    font-size: 14px;
                    color: #fff;
                }

                .bili-header-m .i_menu_login .login-btn:hover {
                    background: #00b5e5;
                }

                .bili-header-m .i_menu_login .reg {
                    margin-top: 8px;
                    text-align: center;
                    font-size: 12px;
                    color: #282828;
                }

                .bili-header-m .i_menu_login .reg a {
                    color: #00a1d6;
                }

                .bili-header-m .i_menu_login .reg a:hover {
                    color: #00b5e5;
                }
            </style>

            <style type="text/css">
                .loc-menu-box {
                    position: absolute;
                    background: #fff;
                    width: 375px;
                    padding: 12px;
                    border-bottom-left-radius: 4px;
                    border-bottom-right-radius: 4px;
                    box-shadow: rgba(0, 0, 0, 0.1) 0 1px 2px;
                }

                .loc-menu-box .loc-link {
                    display: block;
                    position: relative;
                }

                .loc-menu-box .loc-link img {
                    width: 375px;
                    height: 110px;
                    border-radius: 4px;
                }

                .loc-menu-box .loc-link span {
                    position: absolute;
                    color: #fff;
                    left: 0;
                    bottom: 0;
                    width: 375px;
                    line-height: 24px;
                    padding-left: 10px;
                    border-radius: 4px;
                    text-align: left;
                    box-sizing: border-box;
                    background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.6));
                }

                .loc-menu-box .loc-link:first-child {
                    margin-bottom: 12px;
                }
            </style>

            <style type="text/css">
                .channel-menu {
                    position: absolute;
                    padding: 10px 5px;
                    background: #fff;
                    box-shadow: 0 0 5px rgba(0, 0, 0, 0.15);
                    width: 660px;
                    height: 352px;
                    display: flex;
                    text-align: left;
                }

                .channel-menu .box {
                    display: flex;
                    flex-direction: column;
                    flex-wrap: wrap;
                }

                .channel-menu .box a {
                    display: flex;
                    width: 172px;
                    height: 24px;
                    line-height: 24px;
                    padding: 10px 20px !important;
                    color: #212121;
                    border-radius: 4px;
                    transition: all 0.3s;
                    font-size: 14px;
                    justify-content: space-between;
                }

                .channel-menu .box a:hover {
                    background: #f4f4f4;
                }

                .channel-menu .box .name svg {
                    margin-right: 10px;
                }

                .channel-menu .box .count {
                    color: #999;
                }

                .channel-menu .l-box {
                    flex: 2;
                }

                .channel-menu .r-box {
                    flex: 1;
                    padding-left: 5px;
                    border-left: 1px solid #e7e7e7;
                }
            </style>

            <style type="text/css">
                .bili-header-m .bilibili-suggest {
                    position: relative;
                    border: 1px solid #e5e9ef;
                    margin-top: 2px;
                    background: #fff;
                    z-index: 99999;
                    border-radius: 4px;
                    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    padding-bottom: 5px;
                    font-size: 12px;
                }

                .bili-header-m .bilibili-suggest .suggest-item {
                    padding: 6px 10px;
                    cursor: pointer;
                    word-wrap: break-word;
                    word-break: break-all;
                    display: block;
                    color: #222222;
                    position: relative;
                }

                .bili-header-m .bilibili-suggest .suggest-item:hover,
                .bili-header-m .bilibili-suggest .suggest-item.focus {
                    background-color: #e5e9ef;
                }

                .bili-header-m .bilibili-suggest .suggest-item a {
                    max-width: 200px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    color: #222222;
                    display: block;
                }

                .bili-header-m .bilibili-suggest .suggest-item a.link-wrp {
                    display: block;
                }

                .bili-header-m .bilibili-suggest .suggest-item .suggest_high_light {
                    color: #f25d8e;
                }

                .bili-header-m .bilibili-suggest .b-line {
                    border-top: 1px solid #e5e9ef;
                    position: relative;
                    height: 10px;
                    margin: 10px 10px 0 10px;
                }

                .bili-header-m .bilibili-suggest .b-line.history-t {
                    margin: 20px 10px 0 10px;
                    height: 20px;
                }

                .bili-header-m .bilibili-suggest .b-line p {
                    margin-top: -10px;
                    text-align: center;
                }

                .bili-header-m .bilibili-suggest .b-line span {
                    display: inline-block;
                    padding: 0 10px;
                    height: 18px;
                    text-align: center;
                    cursor: pointer;
                    color: #99a2aa;
                    background: #fff;
                }
            </style>

            <style type="text/css">
                .bili-header-m .bilibili-suggest {
                    position: relative;
                    border: 1px solid #e5e9ef;
                    margin-top: 2px;
                    background: #fff;
                    z-index: 99999;
                    border-radius: 4px;
                    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    padding-bottom: 5px;
                    font-size: 12px;
                }

                .bili-header-m .bilibili-suggest .suggest-item {
                    padding: 6px 10px;
                    cursor: pointer;
                    word-wrap: break-word;
                    word-break: break-all;
                    display: block;
                    color: #222222;
                    position: relative;
                }

                .bili-header-m .bilibili-suggest .suggest-item:hover,
                .bili-header-m .bilibili-suggest .suggest-item.focus {
                    background-color: #e5e9ef;
                }

                .bili-header-m .bilibili-suggest .suggest-item a {
                    color: #222222;
                    display: block;
                    max-width: 200px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .bili-header-m .bilibili-suggest .suggest-item a.link-wrp {
                    display: block;
                }

                .bili-header-m .bilibili-suggest .b-line {
                    border-top: 1px solid #e5e9ef;
                    position: relative;
                    height: 10px;
                    margin: 10px 10px 0 10px;
                }

                .bili-header-m .bilibili-suggest .b-line.history-t {
                    margin: 20px 10px 0 10px;
                    height: 20px;
                }

                .bili-header-m .bilibili-suggest .b-line p {
                    margin-top: -10px;
                    text-align: center;
                }

                .bili-header-m .bilibili-suggest .b-line span {
                    display: inline-block;
                    padding: 0 10px;
                    height: 18px;
                    text-align: center;
                    cursor: pointer;
                    color: #99a2aa;
                    background: #fff;
                }

                .bili-header-m .bilibili-suggest .cancel {
                    position: absolute;
                    right: 10px;
                    top: 0px;
                    width: 38px;
                    height: 28px;
                    background: url(../../img/icons.png) -461px -530px no-repeat;
                }

                .bili-header-m .bilibili-suggest .cancel:hover {
                    background-position: -525px -530px;
                }
            </style>

            <style type="text/css">
                .bili-header-m .nav-search #nav_searchform {
                    display: block;
                    border-radius: 2px;
                    background-color: #f4f4f4;
                    border: 1px solid #e7e7e7;
                    padding: 0 30px 0 8px;
                }

                .bili-header-m .nav-search .nav-search-keyword {
                    color: #999;
                    font-size: 12px;
                    overflow: hidden;
                    width: 100%;
                    height: 28px;
                    line-height: 28px;
                    border: none;
                    box-shadow: none;
                    background-color: transparent;
                }

                .bili-header-m .nav-search .nav-search-keyword::-ms-clear {
                    display: none;
                }

                .bili-header-m .nav-search .nav-search-keyword:focus {
                    color: #222222;
                }

                .bili-header-m .nav-search .nav-search-submit {
                    position: absolute;
                    top: 4px;
                    right: 7px;
                    cursor: pointer;
                    margin: 0;
                    padding: 0;
                    border: none;
                    font-size: 18px;
                    color: #999;
                    background: none;
                }

                .bili-header-m .nav-search .nav-search-submit:hover {
                    color: #00a1d6;
                }

                .bili-header-m .nav-search-box {
                    position: relative;
                    margin: 6px 12px 0 15px;
                    width: 460px;
                }

                .bili-header-m .btn-search {
                    display: none;
                    color: #999;
                    font-size: 22px;
                    margin-top: 3px;
                }

                @media screen and (max-width: 1200px) {
                    .stardust-video .nav-search {
                        display: none;
                    }

                    .stardust-video .btn-search {
                        display: block;
                    }

                    .stardust-video .nav-search-box {
                        display: flex;
                        justify-content: flex-end;
                        min-width: 0;
                    }
                }

                @media screen and (max-width: 1400px) {
                    .stardust-common .nav-search {
                        display: none;
                    }

                    .stardust-common .btn-search {
                        display: block;
                    }

                    .stardust-common .nav-search-box {
                        display: flex;
                        justify-content: flex-end;
                        min-width: 0;
                    }
                }
            </style>

            <style type="text/css">
                .bili-header-m .search {
                    position: absolute;
                    bottom: 20px;
                    right: 0;
                    width: 268px;
                    height: 32px;
                    padding: 2px 2px 2px 72px;
                    background-color: #e5e9ef;
                    background-color: rgba(0, 0, 0, 0.12);
                    border-radius: 6px;
                    font-size: 12px;
                    z-index: 10;
                }

                .bili-header-m .search.search-focus .searchform {
                    background-color: #fff;
                }

                .bili-header-m .search .searchform {
                    background-color: #fff;
                    background-color: rgba(255, 255, 255, 0.88);
                    display: block;
                    height: 32px;
                    border-radius: 4px;
                    transition: 0.2s background-color;
                }

                .bili-header-m .search .searchform:hover {
                    background-color: #fff;
                }

                .bili-header-m .search .link-ranking {
                    position: absolute;
                    left: 2px;
                    top: 2px;
                    height: 32px;
                    line-height: 32px;
                    background-color: #fff;
                    background-color: rgba(255, 255, 255, 0.88);
                    border-radius: 4px;
                    width: 68px;
                    transition: 0.2s background-color;
                }

                .bili-header-m .search .link-ranking span {
                    padding-left: 26px;
                    color: #f25d8e;
                    display: inline-block;
                    background: url(../../img/icons.png) -659px -655px no-repeat;
                }

                .bili-header-m .search .link-ranking:hover {
                    background-color: #fff;
                }

                .bili-header-m .search .search-keyword {
                    float: left;
                    width: 200px;
                    color: #222;
                    font-size: 12px;
                    overflow: hidden;
                    height: 32px;
                    line-height: 32px;
                    padding: 0 12px;
                    border: 0;
                    box-shadow: none;
                    background-color: transparent;
                }

                .bili-header-m .search button.search-submit {
                    display: block;
                    position: absolute;
                    right: 0;
                    width: 48px;
                    min-width: 0;
                    cursor: pointer;
                    height: 32px;
                    background: url(../../img/icons.png) -653px -720px;
                    margin: 0;
                    padding: 0;
                    border: 0;
                }

                .bili-header-m .search button.search-submit:hover {
                    background-position: -718px -720px;
                }
            </style>

            <style type="text/css">
                @font-face {
                    font-family: "header-iconfont";
                    src: url(//s1.hdslb.com/bfs/seed/jinkela/header/asserts/iconfont.eot);
                    /* IE9 */
                    src: url(//s1.hdslb.com/bfs/seed/jinkela/header/asserts/iconfont.eot#iefix) format('embedded-opentype'), url('data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAABmMAAsAAAAAKyAAABk/AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHEIGVgCGZgrCBLQZATYCJAN4Cz4ABCAFhUEHgmEbKiMzkrJafbL/w/HG5NA9ZFiIg2BKgiD1ZpBytxrep6/TgcuIbBEf9Z+LBeq32IpK9UO45i8midmqnw+l5OGfe/W+n7EGUDhAiY1OnPN4sQUqYYFrMqZFY21PfE7sBVEvjVioNGJgeH5uvZ/7LNhfJWMj2pXBMMaiGDCqdESqI0TAHhiEgllgoZyViHdwUczgKtGLRrwqAqDNB8z+b7P17zo9RXNavtZ+J9ruZEOAPCQMG056AEDgP4KI1ww+58up30zLM06yILAdbhto8glAMwoUiHORrtLb24AhTsnmAiUpGMogWDj9nW/u1SZFfh5HLAwKOSfu8ku5XOH+L6Wc31GaDjJOkdSA3dzm9iZU7peSYVLCZEAK2ILQZnbWTtc0A0OHLhAQ7e/VaE3LQlpXtI8BeyXeKzc1gRTtiAMtPlf7CNJzrEDiga9PES4f6ZMYbIHmPDZ9zv7KsMnvAgG86L8/fkIbliihUvSc1vaWF4zAN+H93Dqoo+f0ROyfRFLIDJBG8c+t/ASIyc90wfO0qH/GSDp/vJNdfrMlsfoFtcFJP34T/r8DH7ay+t0XBYX17CmHLfIXm8Cqd5//4oEJCCdIimZYjhdYFRsHFw+fgJCImKSU/+XRRUlGkSVydhkRj2icAu9A2cwEeIcQHSPYTILeMcSLcWwmjd4piB8mgAAHAQGmAgGmAQGmAwFmAAFmwxMW60E0gGcD8cNJIFrAi0C0gY0gOsDJILrAJhA9YDOIPrAFxADYCmIInAZiBJwLYgxcA6IOfAFEGfhHbKaCPsKIqo7DUarW0j7G8Aivim8BKocHTy6eoA0FNevlRDAKgCg51pwRGhQf+aJnD3wG54c0q5gzvChSIhtZXdpx5HkefbvR2giw+Tw5fzGZ29qdc5XOEQFfa48bLLo4TsakJgPcLFJu7Y+5vdnmovcyxtuXznslxi106LSVsjSr1nSgIjNFFzhkmkVMGI6ODid8CD67GkCDUe6+m9ibrqOkiNEfQhDj2FgQUOR5xgyLY5ypYexW4KhdRshZBMPQxL5PQN4lF8EMq+RDaXRiV0IDwsNnERjW/UgEmjak5bjJDUZDEQfOtAkGaLWyIQIIYIi9CGYGtzZXGqV77oNBCs0gcDyD7I7tMHuNdyJdRD7dVdGdrXTz+FPnuf3CfUbuhAuPBd/c9Lqss7V7K3+CqXpvJFuNzkjWeprcBoQ/c7eQhtBO5Z0VhFuKwfIalIX9Hy+ufbSm+slA/dP1DcOUrvq5wGmqEq4oTKNC1+XqdKXvW1emhfZJaqL1zXR50XfZqd5PhMgypStRXfQVs5O4+nEyE33YKfX9WJjs+ZjzgoQmNWUqn0/JqLyIJRTDYNlEUiUGSzc5dnWT8B6uy7RumrKQTlFsAYMSw6CmSaXO1d8NQ5PYjEI0EdCUMCC0P0zTMH9XmTIGaypqwOJrEIK2Xgk7WsxkynvqAZiXFOB5pFMca3L7pgelrlfOQyjXOUWr5FYOlw2UP3GyD+dOnxo7FnwgoR3Ydm+V7zt3+6e8OvCkXuwX+u8Dy/fDH++FebgQXgmpc38g6/QW7yIEEuVxr/shM1Bige2yUzQRFBpiCqBJXMVJUodXEpRf70oIVbotiMNAourU47YwUzPP3BedLo3Vg/cOBwPMI8X+Ym3QrNxaXGqgcuB4T9sc7yPPIjXfDYtFnx58YQ8VvSAYeB7+GdR+zd/Pk2rmJYUpZwCIQPsNoWmnOmWlEDbSOk8C8Ai7v8JUpRQdigx1g5n/L1OmtVWCKQZTud4nxZI4YMHrTLmSQlIJx70kSSqyFuTVafsrvs2jnyk78gPl+Oj/vpQbmNLP1Myzt7k+mNav+Zt9aQYLaBDor54elOWq8CsBbSj6/n5tYLBZQYwIs36WmdRf7eHT9jDiydxA5faN2cSqbLF9K0dwy5QJam6+FlnXHrlPbnSOd5vELvR8z7nFlO+yebgaGU10GRQJNwWeZwCL602tXBEEO6IHAxHaW4mY5LkJccguR5wMyHriUVfSKY0Kp9jURLKUK+hjLblabM4gn3Bzvh6fm26QWS2zNwAMDzpaHjlCo88JBlRIfRpjrmbahwk55GKXA7IJZDE09Q6DqfhERyD9YwviQi9MH3R5LNPe/BwZLDr8cPr0oQKPHe0OjpQLGaGk+VoAuOYgZ1EQTw5Pe5urnINkrNs/CICl8ZkFZrhwp4dz1ScZa52r8p46jaG3mIAZokMe1L4TsoE1Ex0Cy5UWuGqcXiF0asdja9wel4ODFiiyN9/7gdszvP4AZ0oUmLv3XXlUk7FCn1STVSCAf1ZpdIsVtQxPNRviAhf6UklIRjn8AGuefdXLHODJ6Hh/9TvP8IuzqPnsHFsgdFPqUrGiikd8ctTv7jlqAbvE/z63mP+z1BaFeU+5+VX2HZQcoVQVA6o1kkn4riwoCSs63m4BqztiZXcytkvwyS37BwqhHtCDUuu9/4MmFOLqT36VY+hTOXNlxUBUdL9P/VjGS75PWqY2dWYYDCWqqNmpw5nST27JlWIrpKkKJE+6p1tl66DVDtVuYFVRJNikIXLK0Jb6eumqa3lSURja0eLWrETctRvbvf/T4L9m+BfxfYNwq+hoI6FNA8fwLOKHu091TL5dpBMT9MJ7RXBpOjQngqG7H5HkiQuX4yNUX5A6PX0pBq58G/rmsBcYo0wTqeY6tZBLKgbDPfMnpws5lfCEwliTAI4rrxYZYnVJtUWaX2grZg1/Cc6mqaVMHcVLI/lTrfHgvOGCB7QSWW2Uq0e8r24HY6wA2YxtY6w5fzE6K3kJt7hXWmenLqMNcw3ZSauYxVdGHCaqTdKD1q16wYCBPmRNcQSXTkRWHUK2N54Un5luBDmjBmYkqsuSb348/PaWv2L8qbfKDRxeuTSrjazVQ3JXWv+Sy8tlA/dNHWgqA9fYi1rXMqN59aBeWUxK/UpxgJZNBG2BkMMAUGFReYxBeIEe2vDfD3yAGmJNxHb3Ts/k2fZWHkm3g28CwykmSuZaD/uaGoZ0qh403JpffcskHekdJTZeHXLqYePdSQ6LBNuPoNHgjCf6vjlOqUEwlKo7VavmNsZ4x5Exkmr9Y+IbiUjAytiw+cWCwShOOZ6+MlmKJYq1ybJDQApMV7zrUQQKU4nZ5IYvQniYD93cNPmsfcb407ciU887Zh5+sRYU7p09c7cXILdNiLPjJyevHI5rGDJt6npw410MceA3C1B6on7hhBVDAOiDl46eWMSQ0ACCPbnp0xOXFy2CKHnm7v1zrQhiFr0AbdUAOVWQubamBNIBTp1/cC+WjOL0gi7LRnYqLvr6YRUsVZLLRJmy+U1ZwOO18nWcG0CcxA4EZ6YafUbLjGS1dyrz61sE7mF1Tg5D4vq+Z5MJAng8/NmtnT1SvXn/XPzwi9X4a+IKEsKWY+NnHt59JwjMw+efPHjb94fC/1ERoDXF8Rjw/xpp0ZFkWVnBEqrvrxcrikrqsky/L80klMSF3h+Erf8otTeEVKnQxgURiuS4IHnpTqMVbgfwciBr0yKOgFCD4VQwENAJaQZtKHfYJhgigDrpt3lG0VuVWmKsK9kTMX87sKIvzPSpXoFWfMeEbn4iZOq8KV31dcK58lHTZdqNmxt6Dem9O9KLuAgKnHNKJA4RMbu3RpSRFiYkZeYwKyRrXVBlV2clbBFNZydcmdIrq+BpZUwLWRaxdXdMYOr3WsXLQAGFhoKXurS7shTgpW5nS3D6w6L/iwpnCpl62/Hurm6yU7Xc5U6+P9+yy5J03+gGSRPr526bOrkP2gsBHFbuvbM4HhcZRLg3HjxaLTLWu3sJ6mjFWhn8Cbb74/tZDZ2R5ysTos6vBJdxiG/zluFPpPCneVGgU4vr0pzR697YOOrxSOmejLGxjPFQWVbXbPHiX9XBrZO/TrYGR24syg/Khb/dlKx7NXgi+NV1kqNz1tgHxYNp6cY6+g76OsBDzZ/pdNU1Zt1nZnN9CrqTp7q6h0OGp4cUQ93dd5gBh31khBUI2B2BcSjwYmbLTHV80JvqJRXWZyO2YItZP10+Hpxt+w05QrxVBXIXNLyZzn+Ld+3/Z5stkxXjIRb7b+j5oBPXnS5Zk8HKNJ9skjtTQPmJSbGkskoyEJxT0elyyZtiZrcOM4nSRvmtPkCqjQ+20lJuZfFbGAKLShzOBU3KDRtCKytD+4+r9OYjgGTdzeN3ejgsOIMnyAPnFCQEC0vszu4UBFKwhnIFm10eHj93WMUiwVzy236qJe9Y4058i/EJ2SMlh96UWXHUVrLYhqqTRRqxMaxKUatixKYy89ooaXTnsiIXsApzo1/e12aualOEoUcusKqUrpMLtfSvqTNmZhlzTlmZILGxA8RnHRTTIlXJxhgXlpDTsqAlJ8GF3awqkyNp1Lb4NKQkIrMInp9UVjtvBRoyK8CYi6GMhsSEpf7kDGmxBhYGclrl9EHIVlJshZQEpQPZhtqvDYUyQ2XOKPWOZfJ51B1YP5XHi3KM2i8AqdgOKo/vx4LuQU4eFewmuABrwXg8rAqz8qoer74VPOhE8tUgvIpWhSM78nYgeAuYs2shJ0Py2lpx9kyT1h+bp2Lj+gyL9ZO157264ees0lRub3uiK4zQOVPHwfxwwyuLwm32sCJYPrT18B+7z1kkKZBFdqgY3r/aQtsy33V0hQJcvXrtmaRaf7zPsTMxKjwysd3Rd0mVH6d8MZH+7PLoY4bTm2zeZQdXxkhFVvhx1bL8s53lZhiedS498EzTyFnzd2SFgsTDRp5A9NTlSNQQsRFu4EdWkXznt9z6dVS+xTCcVGiEF3ZGcoioIX4D3CEExq8G1xq6uw1rV7M1G9puzy4fGY0+h7uQnT7Tn4/O0MpIwVjdosvQ8qaKrt5Qn19lElwQnpHmSo0sIsuM8Zy6DwIFiXbyKdNuKMjPyzc4mFOkPbEAuAW39t6vm5e+adXBiad7bjS/m3/mx12Lj00qL3QQ3zHDjz2ew3i/T9r3vozJYxGeT+Nf9Lip3i9K4otLakuK40tgtBr1q8Rj5jEqzLM7vJ6wmCnirRNKG7exehulonVc8N87TdoJF63mcWSMvj6GrJbWuReuK6XP9H9Le0orPUfZsgeJq9ZWVzOrqamDFrvZOpPlGKMzcx6TFsXLSkgOmLn13ntdmzezamq6/vzz06hPM69L81iv0bsAiRhBv44KqLp+/e8iXm8ExkUbjH4j6ABs5uWdIkJJYd5g7qMWB3lY6wgT3YSyPd+qaQ0EmyVpZgwRpW7TBIVG0VMobay/qR2UCuYFXIlr1A0ECbnjmUfJPloFvaj3Qgrfa95rbNzD2Re6zE31cu/zKamER4vFfSU5oMcyPrJ4EPVZ9pFieivFgxspKo8T97ExP5GZz2/8aFC7FiX8dLq43VuUv8Y1Sj6tk6L37t65YyBDhYupNCjDNp2/Eie8YTyNR4lzv6OuMGA6vIPs2GELgkwgGXbs/4454MXpPUJ9EMuYTFTXLBL6rf0QfcCDa4OWYWxcofYoMSJdoxYQA4fKVUqKlsJheUIxOFtKx5UUngnn4HZgV6ooSopC4afAfXX8KDmsfh5ROrmK0PtXZihR4Ta+yhvu0eDOqKB0k39jeZOXkmTIExJYxu9eXLTnlWohl+J94iXCsSgRB8M1RkyL28lMOh3XUa42ELxwxIo33L8CpsSjlrSvv5du9LfWCLPjSkgTw4wYeXJch+Fe9vPcGzQvvZjqZqQcDQhKexJfebGdEBJ0KBfKg9yoO4naWoiHejeKPG62ifnv1Kl9vu+6GvLnflugqWTVNf+skPiDohOZQ+Qe7mDKUlY9LZ1MwyMb0+whqbtVROxcqjSWTpujh22YTZssSSI03pOSEqhA9LC3twC8tGVp9gOPKleS4bHqTKu+/zVDoRGcR1nnjnYCLXu3bmQq4dOE/ze0HfS3mcZTIzoLlF8AmQshZ36hBTLQlYJ8YCmFzbkFgj8okDBeyBJmETP+eP/MxS/zGgDFQJnWTrNbgB64JPDCC6OLHg+UxY2eYQIm5rNWaQ+IDlRqu4XOP7Oopzf4ZUqDUkadAruOL8/BifIltT5IUuGrrREhvoqixew/7DWvvDoV9UnUT1+L3OkBJqS7A9nmzzqOAPykyr5rzaWKgpbFNNulBJVLuYZX+HZ/EtvE2M8UCt59GHPArK5FMut7HYHeJyZWAceEfJq6SrTHeCx401DbvP74NgHo8XnL91W6On4oyHHnFLT/sO7x9LaNPyRmz69ydXxfWHWSLEUayjdXuNq/r7UaKpzC8ifTR9RfUJlUFYEjn1K2vEP35TQ6/Uu7/v3ljw3eg/KlmblRhOCTuE8EBFQWOhh5W1X1wrVvvS175qwqXHC5hZGaNGdNPn8gun/H+gZKUYb78uVMdwqSjU66+PQ/AfbS3KgFBeoTP4saZuGtAoZQJGIIdJroM+EZ2hR/qv9MPyOXZzsiBT+N9JNg6s2nHoPHc9iDD2rTGk3wK8vFy18J5g3HDHPebt3+efTnbdvBwdj35XMYIkau9H2ZTS6l5SCJYneq3+9KpVLdqTvanWkJS1HYCaA0yAWH4E2Ws8LBXOKrxYweWdHGqLNl9XN8Z8u3viF7RToMdt3wJHnSx9NxvxRTqiH1TCLuTTOk/erzmhxs+zj445VNrazW6tderV6HzVtefa1l2CcSYa04grdiIhFR4XiLRyT0pGF4Cy5k8AD7XwJiEVaN41iAIAyEJBbiLYZcjQnFGDHC2mQHOWw0R42qc1A2BwTFaDmHhYFBMeZxSwDOXRWX7rz8MxHMkrAY8xLy71owK8ZQUOHRJ+je117di+xDXn1NBRfzWtFeTIyOO8gAMAcs48D8CRi+sc8LmjVsGp4FBUJXhn4GkkdYYByapkLvjJABy0gIoBYUIzeawO3VcbUxdbEfpmdkpn8w30JMbdzq26AJPToxUVlBgbSQBmgBmMtqg0t61y2FPjrtKoY1SDi8eKu/Dv6uBu71b3OYYoEVyJEDWHOsMKJGfbPg1xb4yC64PhZtXlg3FPHuo3zGxPP47L8F1/gjGJ8x9kCg/4evGQE+/78Jh/mMRyXQhqVQmoy5yPW5L5EW5ZC2Sh1RMtSzblkxBMgPPhu9S/+MPjz22diQdLh0V1JRfggpU0Q+1zA9+pz0aU+wePQEI3pS3x3t9Xh/AAXLpxmFT7nv699VT6SKiWexk1uh8peufzL44w0PZfR6A3NzpKNe9PVOe1RL2Tl1BLxiuCG4+/+YR7sY0Y8sPVGM6KxvXow6cXh6AtEEjJ7Hc6oPl62MeO7AgTLGqmeyRWMJOvpgUOTcUchAuUPc0ZufbqJubK/dB6LL2E4azUYTu9j5Y3myVfS80eLRGqlaaxs1n/+SGXx3MkfWJm1szYJ9PijLic+nFkK2i+oEh1qZReYajTlktlLtjJdnZk2FTLfeGerZMh1M6cbLXTt+4v+0w9XPngXmlI6HfpT0C9tOzarF7Wdr3bfrqyThuRtfX0qnvHuIlP8MN/pn4yMMclMr6lA3wzSaEzb2+wKusyXz/Lx+0QnuwznWz6kM/suJudFfrihpWhyZpyE0tkxeLpKj9nbHPUIpB4nGJ2+dshkouWushmNAccyyjPoplaXki/W5L7OcdkXcOzwr4esNWvffA3QuGxlS71APIWwufeBvrXvDEvw4fs8VseB2ofQ6FzOaPXpBs/TSdWlhjKBZ7zEbMdrl58tuU6jJ/+WkNZiCPo4gIz6uSTak5fxHTabcLgMbZmb+DQCkCUFociH8UfIYfGWkLvh3MPOTToQeJhr+j7YfngYzP1qDEEiblISQaV87Bv+v/KkZUaJyA6KCGAvHo3yU0TUz/38DMYZ0QPnZ84iEJ25D5urKhBMIH2hNWqcBgOyGfyPJVviX5CXws2QffAuf/A/2TuQQfKnsYjN8gVZPq/er7oTv/+odFuzSNL6yhDn/N4KG8g9/mDlzVe9QrgZAABg8qyAAfuMSYtSHmcm95dBiOXrpe4VLsV/ieUqRIYdeBGwZBgBQXxcB8Mu3lg0+K2s+LzTHeKYra78GBhQQxiO80FgeRahhDQZowMnjCM1eQwWxoPzJNMABfQABEBoEAIgBA1gDATkYXwODYPAdjyD0jzwUsRBvDQb4kI7HEepcQwW5ULVFGoiA7lHNno1AyZpxbxilOLbVq0Bgqc3cD/abfE/QOF2df9V/ahNLMav5knv8GxVq6ZtMG79WdcY1yebTZ3qUkpja5ItQ50G1vi4WjjePOUo+uDp4awRK1hj3bFdGKU7Rq4MQgrW3bzM//jdV+54AvQjXi6vwn7ITt680Vv/79yI8+00o/C7roJ02fk1fojNK6ybZ+IwnUiKKGJU/3BehzoUYcn21IEO5sMI8//w8/QQDutvnxKYBy4qq6YZp2b9Y37Xb48XCxsHFwycgJCImISUjFxKnuU+MJx4ynVooSCeJN3RMRQ0DR+eRMXDsl75LewEdij93MAWWcgT2FApnulLCUCSJ3z/4gTL9NNSeUq/DdPsdNiO0IcvIia5dMBiR6wdi5fBMN3dRzus1CVinQxNBw3AOqLxhvRwTYGwi+aQR2BfGoUJTdlnKMLZIWoRL5EI15IPOzLlkOFWpjKdWuodzy54V0tmeS2WT0wyK4eAA') format('woff2'), url(data:font/woff;base64,d09GRgABAAAAAB4cAAsAAAAAKyAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADMAAABCsP6z7U9TLzIAAAE8AAAARAAAAFY8d0lCY21hcAAAAYAAAAEpAAADZq/Vu8ZnbHlmAAACrAAAGFQAACEEuHNvS2hlYWQAABsAAAAAMQAAADYbGZFiaGhlYQAAGzQAAAAgAAAAJAyeCF5obXR4AAAbVAAAABUAAAB4fMD//mxvY2EAABtsAAAAPgAAAD57DnDwbWF4cAAAG6wAAAAfAAAAIAE6Ac5uYW1lAAAbzAAAAVQAAALB7XHMbXBvc3QAAB0gAAAA/AAAAWH6FtDLeJxjYGRgYOBikGPQYWB0cfMJYeBgYGGAAJAMY05meiJQDMoDyrGAaQ4gZoOIAgCKIwNPAHicY2Bk0WScwMDKwMHUyXSGgYGhH0IzvmYwYuRgYGBiYGVmwAoC0lxTGByeMTxXZW7438AQw9zE0AgUZgTJAQDtYgw1eJzlkkluwkAURKtjZuyQkHliBbsoygJWRCITW5acgSPkUtwg5ylngXIFUt/Fgk1ygfTXs+Uuq7vV/wGoA8jEvagB6RsJMb40m6r5DJ1qvoZPfd/iSDM5EzMW7HPCKedccMkV19yUo+0WIJTWlY6VzvbSYaS/jqTVB6oH1aPqaa+AO+UH2rumMzfQRAttnayr9zH6OMEpznCOC1ziCte4qU6ao8Ahelq68ce+/2Xk8Ugfu69B9MnobsFkouvMjO4brJuwhA0TprBpwiC2DCJvG0TeMYi8axB5bsIsFgaR9031/9iou+DEIPKpUcfBmVHvwWcjC8AXIx/AVyMzwDcjR8B3I1vAuZE34MLIIHBp5BK4MrIKXJu4UW6MTEM5NHIO5cig9wOT2G7cAAAAeJx9eQmUHNV1dt33qupVdXVX9VZVvW/VXTVb92i6p7tn1y6NZhhpJEGQRkhEaDNCtsRmoyDbYnGQRJAXDmCMF5zwExuCE/84OLaDA4kdOMfBCTg5PsY5OY7jYzux/UMc//+ByFP676seCWX5/5nqqlv3bffdd9+937slSAL+0VsoFdpCR1gnrBe2CQI0wHN0YLGkNQkFmIRmp50YdQehwtoz0G0VwDb5m2wGNZqdbgtrsGno4IvJklhUbndHL7/QW8Q/PT93/k/FkDIQ6ndviJrEMg5mU+Ts4Q2Hz9B0/qBhmdEb3P7QgBL6GZSgzH/+M5coePb886L4/Hn/JUWrDpkG5A0rMoct6ZnD87pl+P9kmENVTWmVvlEuf6PUuwtCb25L5HV8hIWokBSQmWiVmyi2U660Y6N2y3RqLXMQTMdstVv4c9pP7gF/zx6f7Hng7FmInT17Zu3UxybXkNeXfFhagotLj585c+aqVzZseOUq3r0YjPEi+aKgC6aQFgZ62kPlSazANeONdBuoKWaDDV2P4eUxG68aw1f6/Ngbjzz8xhh8/fpYc6IZ2/9q5sQDJzKHSEFf/uFbiZv77L7+VP/N8eP+SZ3k9V3wgQeeIOSJB/6uYWcyduPg2oWFte8HmveXfxY984z8DF5nor/9NXwv9F+S7Qz5P4IiWMKosAZl06Hijnaalo3r2JMzWSASayNd5iuOS1tudqbBtpozMA2jKLtkW0kDZNfDtYczMLp1FK/nprcT2D49vYNY/aOQXQN9RT9c7AN8wq8KA2vC2VQkksr6N5zStFPhFECKtDxs2G7f22tGtk/nR/ut62ureq387+FzoJBymW7rr+KvO6tklFlZj3wkoguoXeHiL+h9NByspSXYgiPsEc4KHxYeEj4p/K7weeGPhC/j/IpgMZCHwe1Ch3U7TXxH4T18GAF7NXRqM7AacHbuMK4Uvrt8cpzWwej9iFVEs0e2hcUBPQPtrtftNAj2hRKCQYJKTLZsq9VcjeqyrS72S2aI67WSJvNsrLkavE4XqyHZaXWxPw/HL4Js4nCrgXWRZMSqFapV/+O1aqFWg3dVnzgbLoZXadq5r0a2hMMkEpmNRCACf6GU7JYaEWVWi4almGQm19j1mCtFYyHQWdkaVSJSrywqm+Zqux6vYZn2e3MFUYqZ2q1zMVszSO6IFpOZOl+kohI2FHbLfCQuSrzgMC/YK2W2zDinD1dO7wcgZGrXGULIjhRQApCePYfPyWt/e7s9RZEtVYso9iNV/oAbq//jnKaNaCXtXJQLjGJviaDwO+2SomuxqOTG6/ZqMynFxLBRY7IYUVt2GfWoRXnZUCook8LRmiJLEfWP52/VrKgoFq+KiTSmHc4R9A8KZyoaKc5HAGCFbVvfoWTf3K2nK4dPO7tFlHrK3i4Sa9dTSNJ9c1dx1mRq3rp2UiTAt0PP35FloSVMCZsEoYamPwxmEtdmENqjuIge7gUXtxugn2OmDnawJ7qdbmc18D3Rwe2c5NvDZY4rW92W1XHpzbBxQlElI3pOyxdA2re5um40W2IJ2LpLibx7HjamLCcfUiQ7Bf6BmG1XLEh99qhpWSa//fTxyV0G+ajMgOaiWnaTt/l6CTLNtdXDoaQ+GD25be46YCGTqaI9XqpK8AW7gl3Yp8CpAlQdnBIL5vUIeVPoF2aE1cKscFC4R/h4zxt12qMNwgI3hBMzkzYar20mC9DpctPu4sb2Kq4nV9AfoC/E+bY4V2YOzrMz6lbkrtN2PUdmJv9Z6Dbx1+m2+Q/5/7WMu5DgNuraGCa41/F4P2bgE0dd+gg0Bkh17bxjjU2PWc78Wgf6GqLnTh29rdm67egkOLX/VRwz8zN5a6wQJvs2VTbtI+qXyol8Aq/PWBCSNDA1AM0ETQqBFQL4OpKiBvYlrqSYEmP3SwwG1w4B0xhMXDsBCtw9cnVG07x1g7Jh2bZlyIPrPE1Lb9u3M0emDoxLpZI0fmCKZrfO2VYkYqV+f/NeQvZufoo8bcTjOP7Oy+NeKQL5j1wmmUySJLafyRnHyciMydWRkarMAhu8+HN6J1UwIg0JE8EasY6Lyrdl1vM5ttVxcL3QI+OayUk0weYM4SY4SnW+om6nGxgmvbGyo65kS0prKBGPVa2NhbGsXf1qdtPCprbR2lOdm6vuOXTd5hpUsuNvZTdetTHToWNSeHrgNjJTzaXq15ToXbuSCbsW35SP5GPVXD7fdbzq1m9trbru7HUtIzv1mH8skyOF7PTHJ6X75htlQZBR/h/QSRoV+jCqrBUWhN3CAZwF2g33skzOQ7k96rncC3M7crmZ5QEdJactRsuU+80S32s1V8Ym6DzRiXbs3ksLN1pH8lwZvXaLu9UeiXyPPBuOEpYMqVLG/35aUrWETBMRiIYjRnft+gnI5UnZ//7jTNbOwPozmsT8I6JCTlFGiUxPkT6RQT+oRCEYc4qnJIOeojKhIvkCjUM/slVCnhXj4b5a1FCb433eeFM1otX+SIKOR+IA8ciWsrM5Fo/H/D/w/z6SVg8eVDPhXxIiXlAkAOmCcghE8WlVBPa0+rEL6GovIJuoH1NE9Wnc3CqPyRd/TD9NfMQj5UB7AnQKhOHWdz3XS8S7HQiUwJWJaugit1chCMFBwOp27ALpNES5AGRt9v3nJlNEXD6dS9rhF5+qgf8eKVpA+2tWIiwZBmTD2ZVKh2Fpx3wfsc0Euam+NFuMTu7evaUYmyA/Tk2ee3+WEv8+1UrmYQDYpLj8UarGWNgZUYhWihHVMsn5lWpT1N229TpwygXxe/WJWGl2addktDi7hC5Ixfm9RW+jFcRCGcETVgkjwjR6pHm0EQF4COXTQ/8KQfgsAI+dndGEUyDoUUcDm6/p0PM79EqsBk6S74IV2GKPdnhcTgZqaZOF8MNMNNPKJ94Mp3RZ+4UVMhwtHTPKn+mAns6l9eDmz1iFQr1QPL+X1K+7bvk7e+HO05Xp9dNlILPdzuzOVLypqKrSjKdISvm2lo5KodcekiUrzR4sGmWqO2ooWvMLesowUnl+8wC7KwwV4Ud7/Uf27oUb9/oXnMlKZdLpbAHYkjF1NU8iMQwmIT3J9w1u/g9SB62Aa8cVmsIkRiCHlT2KYUjm0YaZSasbQLAGAM4/D3z+6Egl1EyBIBAZdctBAEIFgX9LC+ZauyCdhqNnaFSDn2oGvW/510dI88iR5W8fIe/SEqoUtcyI5Rejplkyrb977TWSzOuGoefDD9+0PxyFqLb/pof87xwxjuC1JWxh6FXjYQy5JdMsWrhsgdyDpI7+SuBeB0EO7u0KR0toiF0ifFdNp+OMqW/rffrbKmPxdFqFP/muKsuceltHJlaQZTXwfS/QNXSNYAgJRHEClNHSYzjvMq5rbAbpcgwQiINAhCyPbll/5UkE/4XTdA1Syyscis8PLr9A1iyfXoPgNn7Rv/hB5UV6t5DF2L4oHBLuFj4l/KHwDeF14RcgQBSqMAYn4A/gf8KLeDyoeK5TcYcll7tTPLqgT7ITRYBmq2mZRTEpOxgTMba5w+KKLwMEzlaRWA5DxEjdbqfGXXWR9szQox6yuKfzKk6lV4VvVgtVZqK5WxIupne5BGNssMsRXkPT5uUy77cdjFVrBgPJGFM5OEUhWh0paSKjgk6g66F77bSaNgqK3EBSF5mchWNJltzDtC73pBYfu9YTBMN+DwhLScZBfTA7wL67vCeLBSK032FZuMfQN63841Gupy6OY7HDoItgejYaLR+cj2CVrXeaIDBo89kOw6VwMIMdJplso9i96r22ASlhuetJnV5tZgeoSykZ4UxaoRCNaqG4GgEiD6/SFASoOV29MIVxXVTimhKlcrWqEJBoNBaOqJpEmDkgskSIMkkzCdsqi1DPiSA3LnwtqZGQHFEYleeQOx0lSgM+B2oYx2E4jhIGkQ0MhDSZI18iHmdV1DHFsC6CKKeb6ZAEWOC/y0BMESGiWsFAz0SiXngyrMkghlDEBG+giiJRNHgMu0vE8Z0icGWmKRPxBGWJhAqUyom4Rt7+IYhqCiukCWWOLEo0JPbZKYbBRCYglxhklicIK6JwiL1BTpqSKN6MMFhkOQXjF3KSEqX/roQlSU15zWv2rd9gmgWcG0uY4YimhyKE3R+JqMBxPZFEnBlLpxcX1q8pZkPie4qqYlWHlw53x0pOVqViNIbIKR6OAVVqs7VQAgXHUSgKRkSRZbP7lqbH0/9+wj4W2X6tZIpSavUamYopkUxOqHGsqjz3yN7tH1i/XkIVgOpU/PufvoG8KrGTF+459IVAqUosXm98+sOHrpuZyeE0Zf8Yi9fr+7/NUCfyjx9FFWnYNjE9fcf2tQyngVyY2M2I5r9ySlRR+1T50u4zGHQR1mP4lbPZqR27bpcVXsL+5bZJWeTaZqH165xZ+BcC7H5VwprK2HgJlYDvzrtR3bgc8mKlrJCDTkVBsYh8TS7PKBXlzRWH8XLlw1xcWTmpSoBIQXoAhZGxXia9eA8OoeSyff2KTBiwh96VMlFMUCyrfyCJy0blHfk845VcdxPj7/3+3XopVk71p+sxnZvS/j97bv/ehatmphUygeOoqXTk2l0LC1N3TGJ7MRHNGybL9JfTfelmXENlgjow8PRDnxsaOrG4jSnEKOmiqOa62fpQWOu0N29uNXNoD6iTTLSg/0XkGqOa2yjSUNbEqT1DBhpKgD9+Sb9Os0JRGEYvuQU9sNPlGN8Ax0OEniyCcykRgLsxhmcbHSN9xW2jc+5yZy3xIBXgeIxZtStfaLk1ZBQa0dOP3mU0CsZQa+NuQnZvJBMbl4Bem4Jyavk7qQqU0qSeLoEfTpUBSs0SQBna79DkwTpvffIkdmXUydIG/8m5Pbwf2L9hyVdSlUoKdmJ77Gccu5xIlYMbXEELGDx4nPkd2sVY4OEcuY/ESUwDevz2aKcLnabdO+M7UG5avdLRDnnByV8U8s6TRoxJcCSUDsFhleCZOrS8RE7nHSe/zO/wwgucfiFmSIYMLVX1X8GqquifdiYcvHrjv0p/l1pCXChgjJernosAXkRfydDh41GLdtCHVzi4tzrkwff4bx88Sg4dhczx6xKzf2kU+oyfLCws/tUivz3+G+pvHofc8RvFQ9e/deNLRl9eh8xK2eJCL80TrOudiMkljKvDOGPXs2yZn2VlhosW4CYq49g68EDV9dwZDHgm+lerm5BdRlhCGujLHlLk8KBTdazGZxPw8fRMfVBKemX5xBbVkOJuRWq0f+uhz3zo5GdPwhPVPhouLXnDm6PF+VN7xKn1jaj/U2vVo8lyKJmA86/orUQFKVrQM2sN/5rxRgrlDAXCPkj+txARcsKAMC7MCTsQGx4T7hDuFYSEHEDcmd7StHgUmIEgNDIdyv+/Qoy9KCfP2aDdEgwiMQ6R2jEvOPa2EuVeU4RWvEVSBy9h2Wi8wWGq5VyiMYTez1iISffIlinLdyv/GFXvFXGRkME03OdUYSqT7kaYhnflh9HQ3TK7XHrNPUbU/3U0erfODDLBQgjb/c8XhgqEZr0cPfyCn7JToa6MsPy9EVPsylpC+6gC8o6pqZ3oXsQfcHp6eockiXAcfbul/RzDlBX6uQ6Rn4fMCNN+ptkiei9RNrWfhWTNXCmywgyrBkXFUTxxiG2lQCBkhGn/8lt2Pm8T5UA8lU4uXwWe+VuaDnr4lGrF8cz8QVCmFgAWpkQJqUVCtk2LPG+qBOu0kfwbnlNyeM7rX8kPz3LE5srcPyA47XRjDeAbCB0Izx8mLSnAptx1IDq9Er7aK/C9zdMAdpCZo6Hln6QcIOUUSafLhJTTfhme1AxD85fwDl8MHlrA8tuLMLG46P/l4odGInbGjuQGcsk79H79JPkllOzls6lCIUXelyos/8RAhAN46xi4pqDbBry5+NgiXqd0S8fLzGb/9iPR6EdW8sPXk39FLJoVqnhWmcKdin6A41CU3TIRl9KeXaDlFEDSSZA8TVyREa0x7jKtwP+RT/j9BUSmbg6+m6+BK5KF8fF51O7E+Jz/KozMjeBVulXTbo1YQCy49/O2/fl0nZChIa8A6YLnFfwf5VwyMbkVYOsk3sm2Y7UWNLc2W/7bG9WUspFF9HN6uP9AtGMcDGcK38xnBZSez+M95MuX89wpXLMSzqhPGBLquMf2CncJT/w3ue/uFT+4ki7HyjWEeJfTpl2nHeT/8Wjv8FuS53l6uf/LiR72X+pMwn9bh39b+H/WcR9cJJOLi8vfXLxqYeH3e9fWrb526cU/TL6/XIP34hHNftm2qZ16KfW1tCJTWUnLiiIjKQVk6BsZJsuSkpYURcookiyzDJKFhCwiqkqIsixeJgl5bpvf3rYNvrVt/UTvz/9o8ICT/i9vxbFwFBwLRzwe9JcO+oOUpDA5pcgyAo93+EpKZorE2ZL6ibgoA27tOGInUY5hqcTJYHv19tjvoevmXyYGcIetQW+4W7gBrbDZ6aHqIFvmuQwPf9ZKwj7w5l6DdJoFPDJ6gXE2uf+iFZebKZEdZI4GxU5CD5LUBY67eQRo9JKXHfJUppsZKkE8G4fhqY2bIgmIvSi9/PAjL4niyw8//PLjlTrUN9ShUf4aUnRo3RCFegWd6FClXCfD5a9W6kNYPFx6/tav1AeHFnd+76ajd4L02mF0BmW8nkWY2urX43F9bHdYlmPZxD89zLt+5OGXRfmlLbxv3v457LQ0OFiq1P1zw+vqBIbWDz8fFK4fxsI7j970+o7FwcH6V2799Gv+Yxj6R8rllXP0J8gfBjkUbt8bg+wCThVBm9u99I2KloPjtJ3oBunMBleQx6OHzdOcK7TZo9srtBOgH1Mu8kgxQ/gp3KM30/PHXn9yrwj0d2765xvP0zcuCrd9SqY3fvlX7/sUlT41aebRiTVyIJbsZ60c0vW8WLKetfKk1OAU2H+z7zR67fnjoPVtGctLH9gLd+z7AJkHGk/Wrr+L0ruuh7j46O2DKdv/6yX64InB2x/1nyiYdoEUbSubtwLCzF0mQCfHtuWj0R9M5Me29OW3v5tc/hbFv3cZwmrhY3zH/+fTNZidAurJMx18b7f04NPGMLTaMjeobqsdfNtzOvxjSNJ28tDtcCPj50vTadvWDOrDgLZj8SwkOoUrenBWOjCdIM3Ls1dmKwAZFmtd7hJPsx5CSQyzQf6G571i8A/1KYCpul+pTxKYglxmxE60sm/i27kYyQ+WqSGexaPkMHirIm8g96RBnEbJuD+Sa2jFnMwiYSNhenFjwEzcoCVbI6nwibNRWhgoU106F+m1i2RqNegrS7JxJGSPtbRQ6IaTUVKtl4y/jtdCcjYZCf9DTFUxZn/vkihkss5F8x87sNIpFrxhoDiFgZjUj4eDqaUZWELmrxP1MqkMxuCAKOXH6rjhpRMfUtTogBdX1Pfy2Yxm9UsN+7DZalg6uqrR3+LHsU4Oz765dDoSb5R4J58LhWJaBMRkFtiHtGo8FKT2ezZ/G3lGSAsO4rtJYbOwE9e324tURf6xwlxZ6HbM7XRZOWbJHsftPYPvBTEbnYJOsMo7JHJrLZ5JYw73GjAQl2IabNLiUnxX3gU3v/xE3oO+/AbyIxgqLj+d74Nbrj5OyPGre/fGFie29jeuGSE7VxdXpcKD4+MIzceBzYUMIzSHoZscaIXCmtYifXn/PmwN/Tk4me+HZ/x/LQ7xlzvopb6uPj4ycvW1a2POXH311cPlsYlBzR4p9k0cBIzbwG8rurj4Jj1OeeTLo9/soNfcy/c/5amRGcrz4p24x5GJjtZsiRS3f8dlUpAyB7eXR0OOZxeCT34Y4EYx2vF8iY0wMohM/Csf630doYdpYXRNZfZqtvI8dyJ3beQY8wfiJHoLdP5t4ZAEZsR/KhIVzffBMxqe6CNJdCYQ/2YnYSiy4iY6otiWMeTL4n6qiyxk6NmaCO4Y3r5VmRxKUu3o7MrT33wE3HvViH8oNpwgdxUhpN20oCegRmx9bieqNpQwo0yOaro9YYdqSR2HSBGF2FTuYrA5F4GQcjOlkpdN2WE3++kVv3AfeUUYQYSzWfhNjC9mq2lh+F05FI12JoF/Ar6UCWuvHPXMIJ/EOL6uBWcnJGyrhti3w9XnOhLu59UcQa/GcFQkXJ02mh0pHwvpesj/Mb8fG5zPfXJYaa3SwknIJuEjaNnJsLaqpQx/Mjfv/7mclCRcpBTJy62UaJmS5P9qioVBW4XRe32B4k5ej2F1lQZh9pkNeijGO8XbBtkrrPrJqgWNxLFH7DlOtAVkFLyvZHNfArFs3v5HX8plJ283yyJ8sUhVZV0DDwihKcamQmDIjXWKyj8H/l8eHBBheJxjYGRgYADiRYaFR+P5bb4ycLMwgMDNucs2wej///7XcxxkbgJyORiYQKIAcf4OKQAAAHicY2BkYGBu+N/AEMNx4P+///85DjIARVCAHADCfggLeJxjYWBgYCETcxz4/49cvQC9DAM6AAAAAAAAAABuAKAA7gFUAngC5AO6BBoEuAUoBbYGEgY4BmYI+AlsCawJ5Ao4CwwLfgviDL4NWg3mDtQPWg/yEIIAAHicY2BkYGCQYzzEIMQAAkxAzAWEDAz/wXwGACAeAgoAeJyFks1OwkAUhc/wZyyJJhpcmlkYFxrKjzu2JBC2xLAv7bRA+pfpQMJL+A4+iE/gO7j3Cdx6KMOmJtLJ3Hz33HM7d5oCuMEXBI5Ph/vIAtfMjlzDBR4s16k/W26QR5abaGNmuUX91bJDt2+5jVu88Q2iccnsCe+WBe7xabmGK3xbrlP/sdzAvehYbuJOvFhuUZ9ZdrAQkeU2HsWHM9bKMyqQy71c+1kaZqlxVsoLlO6e8rmKtrGnK2olXShdrLNUDtx+pTJVqdKnM4pdNDQmlKHOEjlhVcVxJnOdbZRv3JUx+ajXC63u+lnCkcfQUPBgGANILLFnXPOjZUgRltHQtypdAaNG9099Tj3CFjE9+oz3/+qi1Avqh1xiABf9Mz1T6mlZq96jwI5zDakauiW3Zk9CmthexZljskRe1jZUfOouzzx05fzFelxhxe+WMyS/LASERHicbU5bTsNAEIvbbENaWgqUN5QTcBWuEE02291R96VkN1JvTyoeX1iyZI9seYpZ8Y1l8T/2mGGOEgILVLhAjSVWuMQaG1xhi2vc4BY73OEeD3jEE57xgle8YY/3Qrg8sCw1OSU68lKVlkc1Vz5N4qCqI0vDx1zrHKTJ5HV1oMFw8DPqBHl2apmUND7YoE9brbzqyTYxW5tjM6w/aWypb1xo2arVj5uiYTUd+MyPNG5+aznaQN2fHRT10lQkE4+c6taSPPYhuLJX1O1YNpH6xGl6pmn7qSipluxVNNPW4qwciRQiS9GFrKnqWHMiuzixj+yFoyRNUXwB8bRgZQ==) format('woff'), url(//s1.hdslb.com/bfs/seed/jinkela/header/asserts/iconfont.ttf) format('truetype'), url(//s1.hdslb.com/bfs/seed/jinkela/header/images/iconfont.svg#header-iconfont) format('svg');
                    /* iOS 4.1- */
                }

                .header-iconfont {
                    font-family: "header-iconfont" !important;
                    font-size: 16px;
                    font-style: normal;
                    -webkit-font-smoothing: antialiased;
                    -moz-osx-font-smoothing: grayscale;
                }

                .header-icon-music:before {
                    content: "\E601";
                }

                .header-icon-game:before {
                    content: "\E603";
                }

                .header-icon-dance:before {
                    content: "\E605";
                }

                .header-icon-live:before {
                    content: "\E606";
                }

                .header-icon-ent:before {
                    content: "\E607";
                }

                .header-icon-life:before {
                    content: "\E608";
                }

                .header-icon-kichiku:before {
                    content: "\E609";
                }

                .header-icon-guochuang:before {
                    content: "\E60A";
                }

                .header-icon-fashion:before {
                    content: "\E60B";
                }

                .header-icon-ad:before {
                    content: "\E60C";
                }

                .header-icon-anime:before {
                    content: "\E60D";
                }

                .header-icon-guochandonghuatuijian:before {
                    content: "\E612";
                }

                .header-icon-technology:before {
                    content: "\E6AD";
                }

                .header-icon-general_pullup_s:before {
                    content: "\E6EC";
                }

                .header-icon-Navbar_mobile:before {
                    content: "\E724";
                }

                .header-icon-Navbar_logo:before {
                    content: "\E725";
                }

                .header-icon-bilibili-tv:before {
                    content: "\E668";
                }

                .header-icon-general_upload:before {
                    content: "\E634";
                }

                .header-icon-general_search:before {
                    content: "\E635";
                }

                .header-icon-activit:before {
                    content: "\E63B";
                }

                .header-icon-blackroom:before {
                    content: "\E63F";
                }

                .header-icon-read:before {
                    content: "\E640";
                }

                .header-icon-ic_partition_broadca:before {
                    content: "\E641";
                }

                .header-icon-cinephile:before {
                    content: "\E642";
                }

                .header-icon-cinema:before {
                    content: "\E643";
                }

                .header-icon-topic:before {
                    content: "\E644";
                }

                .header-icon-douga:before {
                    content: "\E645";
                }

                .header-icon-digital:before {
                    content: "\E64E";
                }

                .header-icon-yinpin:before {
                    content: "\E656";
                }

                .header-icon-match:before {
                    content: "\E600";
                }
            </style>

            <style type="text/css">
                .bili-header-m {
                    font: 12px 'Helvetica Neue', Helvetica, Arial, 'Microsoft Yahei', 'Hiragino Sans GB', 'Heiti SC', 'WenQuanYi Micro Hei', sans-serif;
                    position: relative;
                    z-index: 10000;
                    background: #fff;
                    margin: 0;
                    padding: 0;
                }

                .bili-header-m dl,
                .bili-header-m dt,
                .bili-header-m dd,
                .bili-header-m ul,
                .bili-header-m ol,
                .bili-header-m li,
                .bili-header-m h1,
                .bili-header-m h2,
                .bili-header-m h3,
                .bili-header-m h4,
                .bili-header-m h5,
                .bili-header-m h6,
                .bili-header-m pre,
                .bili-header-m code,
                .bili-header-m form,
                .bili-header-m fieldset,
                .bili-header-m legend,
                .bili-header-m input,
                .bili-header-m textarea,
                .bili-header-m p,
                .bili-header-m blockquote,
                .bili-header-m th,
                .bili-header-m td,
                .bili-header-m hr,
                .bili-header-m button,
                .bili-header-m article,
                .bili-header-m aside,
                .bili-header-m details,
                .bili-header-m figcaption,
                .bili-header-m figure,
                .bili-header-m footer,
                .bili-header-m header,
                .bili-header-m hgroup,
                .bili-header-m menu,
                .bili-header-m nav,
                .bili-header-m section {
                    margin: 0;
                    padding: 0;
                }

                .bili-header-m input,
                .bili-header-m select,
                .bili-header-m textarea {
                    font-size: 100%;
                }

                .bili-header-m table {
                    border-collapse: collapse;
                    border-spacing: 0;
                }

                .bili-header-m th {
                    text-align: inherit;
                }

                .bili-header-m fieldset,
                .bili-header-m img {
                    border: none;
                    vertical-align: middle;
                }

                .bili-header-m abbr,
                .bili-header-m acronym {
                    border: none;
                    font-variant: normal;
                }

                .bili-header-m del {
                    text-decoration: line-through;
                }

                .bili-header-m address,
                .bili-header-m caption,
                .bili-header-m cite,
                .bili-header-m code,
                .bili-header-m dfn,
                .bili-header-m em,
                .bili-header-m th,
                .bili-header-m var {
                    font-style: normal;
                    font-weight: normal;
                }

                .bili-header-m ol,
                .bili-header-m ul {
                    list-style: none;
                }

                .bili-header-m caption,
                .bili-header-m th {
                    text-align: left;
                }

                .bili-header-m h1,
                .bili-header-m h2,
                .bili-header-m h3,
                .bili-header-m h4,
                .bili-header-m h5,
                .bili-header-m h6 {
                    font-size: 100%;
                    font-weight: normal;
                }

                .bili-header-m q:before,
                .bili-header-m q:after {
                    content: '';
                }

                .bili-header-m sub,
                .bili-header-m sup {
                    font-size: 75%;
                    line-height: 0;
                    position: relative;
                    vertical-align: baseline;
                }

                .bili-header-m sup {
                    top: -0.5em;
                }

                .bili-header-m sub {
                    bottom: -0.25em;
                }

                .bili-header-m a {
                    transition: color 0s;
                }

                .bili-header-m a:hover {
                    text-decoration: none;
                }

                .bili-header-m ins,
                .bili-header-m a {
                    text-decoration: none;
                }

                .bili-header-m a:focus,
                .bili-header-m *:focus {
                    outline: none;
                }

                .bili-header-m .clearfix:before,
                .bili-header-m .clearfix:after {
                    content: "";
                    display: table;
                }

                .bili-header-m .clearfix:after {
                    clear: both;
                    overflow: hidden;
                }

                .bili-header-m .clearfix {
                    zoom: 1;
                }

                .bili-header-m .clear {
                    clear: both;
                    display: block;
                    font-size: 0;
                    height: 0;
                    line-height: 0;
                    overflow: hidden;
                }

                .bili-header-m .hide {
                    display: none;
                }

                .bili-header-m .block {
                    display: block;
                }

                .bili-header-m .fl,
                .bili-header-m .fr {
                    display: inline;
                }

                .bili-header-m .fl {
                    float: left;
                }

                .bili-header-m .fr {
                    float: right;
                }

                .bili-header-m .bili-icon {
                    display: inline-block;
                    background-image: url(../../img/icons.png);
                }

                .bili-header-m .nav-wrapper {
                    min-width: 980px;
                    display: flex;
                    justify-content: space-between;
                }

                .bili-header-m .nav-wrapper .nav-con-ul {
                    display: flex;
                }

                .bili-header-m .nav-wrapper-right {
                    display: flex;
                }

                .bili-header-m .bili-wrapper {
                    margin: 0 auto;
                    width: 1160px;
                }

                @media screen and (max-width: 1400px) {
                    .bili-header-m .bili-wrapper {
                        width: 980px;
                    }
                }

                .bili-header-m .bili-wrapper .l-con {
                    float: left;
                    width: 900px;
                }

                @media screen and (max-width: 1400px) {
                    .bili-header-m .bili-wrapper .l-con {
                        width: 720px;
                    }
                }

                .bili-header-m .bili-wrapper .r-con {
                    width: 260px;
                    float: right;
                }

                .bili-header-m .bi-btn {
                    display: inline-block;
                    background: #00a1d6;
                    color: #fff;
                    font-size: 14px;
                    padding: 4px 18px;
                    border-radius: 4px;
                    transition: all 0.3s;
                    user-select: none;
                    border: 1px solid #00a1d6;
                    text-align: center;
                    cursor: pointer;
                }

                .bili-header-m .bi-btn:hover {
                    color: #fff;
                    background: #00b5e5;
                    border-color: #00b5e5;
                }

                .bili-header-m .bi-btn:active {
                    background: #01769c;
                    border-color: #01769c;
                }

                .bili-header-m .nav-menu {
                    position: relative;
                    z-index: 200;
                    height: 42px;
                    color: #222;
                }

                .bili-header-m .nav-menu .blur-bg {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-position: center -10px;
                    background-repeat: no-repeat;
                    filter: blur(4px);
                }

                .bili-header-m .nav-menu .nav-mask {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(255, 255, 255, 0.4);
                    box-shadow: rgba(0, 0, 0, 0.1) 0 1px 2px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item {
                    float: left;
                    text-align: center;
                    line-height: 42px;
                    height: 42px;
                    position: relative;
                    background-color: rgba(255, 255, 255, 0);
                    white-space: nowrap;
                }

                .bili-header-m .nav-menu .nav-con .nav-item .t {
                    white-space: nowrap;
                    color: #222;
                    height: 100%;
                    display: block;
                    padding: 0 7px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item .t .num {
                    height: 12px;
                    line-height: 12px;
                    color: #fff;
                    background-color: #f25d8e;
                    border-radius: 10px;
                    position: absolute;
                    padding: 1px 2px;
                    font-size: 12px;
                    top: 1px;
                    right: -4px;
                    min-width: 16px;
                    z-index: 30;
                    text-align: center;
                }

                .bili-header-m .nav-menu .nav-con .nav-item .t .dot {
                    width: 6px;
                    height: 6px;
                    background-color: #f25d8e;
                    border-radius: 50%;
                    position: absolute;
                    right: 5px;
                    top: 8px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item .new {
                    position: absolute;
                    top: 6px;
                    right: -6px;
                    width: 22px;
                    height: 9px;
                    background-position: -851px -412px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item .text-red {
                    position: absolute;
                    top: 2px;
                    right: -4px;
                    width: 24px;
                    height: 12px;
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/yizhounian.png) no-repeat;
                }

                .bili-header-m .nav-menu .nav-con .nav-item .red_point {
                    height: 8px;
                    width: 8px;
                    border-radius: 100%;
                    position: absolute;
                    right: 6px;
                    top: 7px;
                    background-color: #f25d8e;
                }

                .bili-header-m .nav-menu .nav-con .nav-item:hover {
                    background-color: rgba(255, 255, 255, 0.3);
                }

                .bili-header-m .nav-menu .nav-con .nav-item.profile-info:hover {
                    background: none;
                }

                .bili-header-m .nav-menu .nav-con .nav-item.home {
                    margin-left: -10px;
                    padding-left: 12px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item.home a {
                    padding-left: 20px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item.home .header-icon-bilibili-tv {
                    position: absolute;
                    left: 9px;
                    top: -1px;
                    color: #00a1d6;
                    font-size: 20px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item.mobile {
                    padding: 0 5px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item.mobile a {
                    display: inline-block;
                    padding: 0;
                }

                .bili-header-m .nav-menu .nav-con .nav-item.mobile .b-icon-app {
                    vertical-align: middle;
                    font-size: 16px;
                    line-height: 17px;
                    color: #23ADE5;
                }

                .bili-header-m .nav-menu .nav-con .nav-item .i-frame {
                    position: absolute;
                    left: 0;
                    top: 42px;
                }

                .bili-header-m .nav-menu .nav-con .nav-item .app-orcode-box {
                    position: absolute;
                    background: #f00;
                    left: -20px;
                    top: 42px;
                    width: 259px;
                    height: 174px;
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/orcode-frame.png);
                }

                .bili-header-m .nav-menu .nav-con .nav-item .app-orcode-box:before {
                    content: '';
                    position: absolute;
                    width: 97px;
                    height: 97px;
                    left: 82px;
                    top: 30px;
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/app-orcode.png);
                }

                .bili-header-m .nav-menu .nav-con .manga {
                    position: relative;
                }

                .bili-header-m .nav-menu.blur-black .nav-mask {
                    background-color: rgba(0, 0, 0, 0.4);
                }

                .bili-header-m .nav-menu.blur-black .nav-con .nav-item .t {
                    color: #fff;
                }

                .bili-header-m .nav-menu.blur-black .nav-con .nav-item.home .header-icon-bilibili-tv {
                    color: #fff;
                }

                .bili-header-m .nav-menu .up-load {
                    position: relative;
                    width: 68px;
                    height: 42px;
                    margin-left: 5px;
                }

                .bili-header-m .nav-menu .up-load .u-link {
                    display: block;
                    width: 68px;
                    height: 46px;
                    line-height: 42px;
                    text-align: center;
                    font-size: 14px;
                    color: #fff;
                    background-color: #f45a8d;
                    border-radius: 0 0 6px 6px;
                }

                .bili-header-m .nav-menu .up-load .upload-new-icon {
                    position: absolute;
                    width: 54px;
                    height: 34px;
                    top: 4px;
                    right: -53px;
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/up-new-iocn.png) no-repeat;
                    z-index: 20;
                }

                .bili-header-m .nav-menu .up-load:hover .u-link {
                    background-color: #fb7299;
                }

                .bili-header-m .nav-menu .up-load .up-nav {
                    width: 272px;
                    position: absolute;
                    right: 0;
                    top: 42px;
                    background: #fff;
                    border-radius: 0 0 4px 4px;
                    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    overflow: hidden;
                    z-index: 1;
                }

                .bili-header-m .nav-menu .up-load .up-nav li {
                    cursor: pointer;
                    text-align: center;
                    width: 68px;
                    height: 64px;
                    transition: 0.2s;
                    float: left;
                    position: relative;
                    background: #fff;
                }

                .bili-header-m .nav-menu .up-load .up-nav li a {
                    color: #f25d8e;
                    display: block;
                    width: 100%;
                    height: 100%;
                }

                .bili-header-m .nav-menu .up-load .up-nav li a .rect {
                    display: block;
                    width: 20px;
                    height: 20px;
                    margin: 15px auto 2px;
                    transition: 0.2s;
                }

                .bili-header-m .nav-menu .up-load .up-nav li a .rect.i-art {
                    background-position: -534px -919px;
                }

                .bili-header-m .nav-menu .up-load .up-nav li a .rect.i-ap {
                    background-position: -534px -983px;
                }

                .bili-header-m .nav-menu .up-load .up-nav li a .rect.i-vp {
                    background-position: -471px -919px;
                }

                .bili-header-m .nav-menu .up-load .up-nav li a .rect.i-vm {
                    background-position: -471px -982px;
                }

                .bili-header-m .nav-menu .up-load .up-nav li a .rect.i-vc {
                    background-position: -471px -1751px;
                }

                .bili-header-m .nav-menu .up-load .up-nav li:hover {
                    background: #e5e9ef;
                }

                .bili-header-m .nav-menu .up-load .up-nav li:hover .rect {
                    transform: translateY(-2px);
                }

                .bili-header-m .nav-menu .up-load .up-nav li .new {
                    position: absolute;
                    top: 6px;
                    right: 0;
                    width: 22px;
                    height: 9px;
                    background-position: -851px -412px;
                }

                .bili-header-m .nav-menu .up-load .up-nav li .beta {
                    position: absolute;
                    top: 6px;
                    right: 0;
                    width: 22px;
                    height: 9px;
                    background-position: -854px -1307px;
                }

                .bili-header-m .nav-menu .dd-bubble {
                    position: absolute;
                    z-index: 1;
                }

                .bili-header-m .profile-info {
                    width: 46px;
                }

                .bili-header-m .profile-info .i-face {
                    position: absolute;
                    z-index: 20;
                    width: 32px;
                    height: 32px;
                    left: 8px;
                    top: 0px;
                    transition: 0.3s;
                }

                .bili-header-m .profile-info .i-face .face {
                    border: 0 solid #fff;
                    width: 100%;
                    height: 100%;
                    border-radius: 50%;
                }

                .bili-header-m .profile-info .i-face .legalize {
                    background-image: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/user-auth.png);
                    width: 20px;
                    height: 20px;
                    position: absolute;
                    bottom: 10px;
                    right: 7px;
                    visibility: hidden;
                    transition-delay: 0s;
                }

                .bili-header-m .profile-info .i-face .legalize.vip {
                    background-position: -72px -52px;
                }

                .bili-header-m .profile-info .i-face .legalize.small-vip {
                    background: url(//s1.hdslb.com/bfs/seed/jinkela/header/images/green_vip.png);
                }

                .bili-header-m .profile-info .i-face .legalize.p-ver {
                    background-position: -38px -52px;
                }

                .bili-header-m .profile-info .i-face .legalize.e-ver {
                    background-position: -4px -52px;
                }

                .bili-header-m .profile-info .i-face .pendant {
                    position: absolute;
                    width: 84px;
                    height: 84px;
                    left: -11px;
                    bottom: -3px;
                    visibility: hidden;
                    transition-delay: 0s;
                }

                .bili-header-m .profile-info.on .i-face {
                    left: -8px;
                    top: 15px;
                    height: 64px;
                    width: 64px;
                }

                .bili-header-m .profile-info.on .i-face .face {
                    border: 2px solid #fff;
                }

                .bili-header-m .profile-info.on .i-face .legalize {
                    bottom: -4px;
                    right: -3px;
                    transition-delay: 0.28s;
                    visibility: visible;
                }

                .bili-header-m .profile-info.on .scale-in .face {
                    width: 48px;
                    height: 48px;
                }

                .bili-header-m .profile-info.on .scale-in .legalize {
                    bottom: 10px;
                    right: 7px;
                    transition-delay: 0.28s;
                    visibility: visible;
                }

                .bili-header-m .profile-info.on .scale-in .pendant {
                    transition-delay: 0.28s;
                    visibility: visible;
                }

                .bili-header-m .head-banner {
                    position: relative;
                    z-index: 199;
                    height: 170px;
                    margin-top: -42px;
                    background: #eee;
                    background-position: center -10px;
                    background-repeat: no-repeat;
                }

                .bili-header-m .head-banner .banner-link {
                    position: absolute;
                    left: 0;
                    top: 0;
                    height: 100%;
                    width: 100%;
                }

                .bili-header-m .head-banner .head-content {
                    position: relative;
                    height: 170px;
                }

                .bili-header-m .head-banner .head-content .head-title {
                    position: absolute;
                    top: 114px;
                    left: 255px;
                    line-height: 20px;
                    padding: 6px 10px;
                    background-color: rgba(0, 0, 0, 0.68);
                    color: #fff;
                    border-radius: 4px;
                    font-size: 14px;
                    max-width: 350px;
                    opacity: 0;
                    transition: all 0.2s;
                }

                .bili-header-m .head-banner .head-content .head-logo {
                    position: absolute;
                    width: 220px;
                    height: 105px;
                    left: 24px;
                    top: 55px;
                    background: transparent no-repeat left center;
                    z-index: 10;
                }

                .bili-header-m .head-banner:hover .head-content .head-title {
                    opacity: 1;
                }

                .bili-header-m .b-icon {
                    display: inline-block;
                    vertical-align: middle;
                    width: 12px;
                    height: 12px;
                    background: url(../../img/icons.png) no-repeat;
                }

                .bili-header-m .b-icon.b-icon-p-member,
                .bili-header-m .b-icon.b-icon-p-account,
                .bili-header-m .b-icon.b-icon-p-wallet,
                .bili-header-m .b-icon.b-icon-p-live {
                    width: 16px;
                    height: 16px;
                }

                .bili-header-m .b-icon.b-icon-p-member {
                    background-position: -472px -344px;
                }

                .bili-header-m .b-icon.b-icon-p-account {
                    background-position: -472px -407px;
                }

                .bili-header-m .b-icon.b-icon-p-wallet {
                    background-position: -472px -472px;
                }

                .bili-header-m .b-icon.b-icon-p-live {
                    background-position: -473px -855px;
                }

                .bili-header-m .b-icon.b-icon-vp {
                    background-position: -471px -919px;
                }

                .bili-header-m .b-icon.b-icon-vm {
                    background-position: -471px -982px;
                }

                .bili-header-m .b-icon.b-icon-vc {
                    background-position: -471px -1751px;
                }

                .bili-header-m .b-icon.b-icon-arrow-r {
                    background-position: -478px -218px;
                    width: 6px;
                    height: 12px;
                    margin: -2px 0 0 5px;
                }

                .bili-header-m .b-icon.b-icon-ap {
                    background-position: -534px -983px;
                }

                .bili-header-m .b-icon.b-icon-art {
                    background-position: -534px -919px;
                }

                .bili-header-m .mini-wnd-nav {
                    position: absolute;
                    left: 0;
                    top: 42px;
                    background-color: #fff;
                    width: 320px;
                    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    border: 1px solid #e5e9ef;
                    border-radius: 0 0 4px 4px;
                    z-index: 200;
                }

                .bili-header-m .mini-wnd-nav a {
                    color: #222;
                    transition: color 0.2s;
                }

                .bili-header-m .mini-wnd-nav .list {
                    padding-top: 10px;
                }

                .bili-header-m .mini-wnd-nav .list.history li {
                    clear: both;
                    position: relative;
                    padding-left: 38px;
                }

                .bili-header-m .mini-wnd-nav .list.history li:before {
                    left: 26px;
                }

                .bili-header-m .mini-wnd-nav .list.history li.timeline {
                    color: #99a2aa;
                    overflow: visible;
                    height: 0;
                    padding: 0;
                    margin: 10px 0;
                    border-top: 1px solid #e5e9ef;
                    position: relative;
                }

                .bili-header-m .mini-wnd-nav .list.history li.timeline:before {
                    display: none;
                }

                .bili-header-m .mini-wnd-nav .list.history li.timeline .date {
                    background-color: #fff;
                    position: absolute;
                    top: -6px;
                    left: 0;
                    z-index: 10;
                    padding: 0 10px 0 10px;
                    height: 12px;
                    line-height: 12px;
                }

                .bili-header-m .mini-wnd-nav .list.history li.no-data {
                    border: none;
                    padding: 0;
                }

                .bili-header-m .mini-wnd-nav .list.history li a {
                    max-width: none;
                    float: inherit;
                }

                .bili-header-m .mini-wnd-nav .list li {
                    height: 28px;
                    line-height: 28px;
                    text-align: left;
                    font-size: 12px;
                    overflow: hidden;
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    padding: 0 12px 0 22px;
                    position: relative;
                }

                .bili-header-m .mini-wnd-nav .list li:before {
                    content: '';
                    display: block;
                    position: absolute;
                    top: 13px;
                    left: 10px;
                    width: 4px;
                    height: 4px;
                    border-radius: 2px;
                    background-color: #6d757a;
                }

                .bili-header-m .mini-wnd-nav .list li:hover {
                    background-color: #e5e9ef;
                }

                .bili-header-m .mini-wnd-nav .list li.no-data {
                    text-align: center;
                    color: #aaa;
                }

                .bili-header-m .mini-wnd-nav .list li a {
                    overflow: hidden;
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    display: block;
                }

                .bili-header-m .mini-wnd-nav .list li a:hover {
                    color: #00a1d6;
                }

                .bili-header-m .mini-wnd-nav .list li .link {
                    overflow: hidden;
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    display: inline-block;
                }

                .bili-header-m .mini-wnd-nav .read-more {
                    display: block;
                    margin: 4px 12px 12px;
                    background-color: #e5e9ef;
                    text-align: center;
                    border: 1px solid #e0e6ed;
                    height: 22px;
                    line-height: 22px;
                    color: #222222;
                    border-radius: 4px;
                }

                .bili-header-m .mini-wnd-nav .read-more:hover {
                    background-color: #ccd0d7;
                }

                .bili-header-m .mini-wnd-nav .m-w-loading {
                    height: 100px;
                    line-height: 100px;
                    text-align: center;
                }

                .slide-fade-enter-active,
                .slide-fade-leave-active {
                    transition: all 0.3s;
                }

                .slide-fade-enter,
                .slide-fade-leave-to {
                    transform: translateY(5px);
                    opacity: 0;
                }

                .stardust-video .nav-menu {
                    height: 50px;
                }

                .stardust-video .nav-menu .nav-wrapper {
                    min-width: 1120px;
                }

                .stardust-video .nav-menu .i_menu_login {
                    margin-left: -180px;
                }

                .stardust-video .nav-menu .nav-con .nav-item {
                    line-height: 50px;
                    height: 50px;
                }

                .stardust-video .nav-menu .nav-con .nav-item .t .num {
                    top: 5px;
                }

                .stardust-video .nav-menu .nav-con .nav-item.home {
                    margin-left: 80px;
                    padding-left: 12px;
                }

                .stardust-video .nav-menu .nav-con .nav-item.home a {
                    padding-left: 12px;
                }

                .stardust-video .nav-menu .nav-con .nav-item.home .header-icon-Navbar_logo {
                    position: absolute;
                    width: 80px;
                    height: 42px;
                    left: -68px;
                    top: 8px;
                    color: #00a1d6;
                    font-size: 32px;
                    line-height: 32px;
                    cursor: pointer;
                }

                .stardust-video .nav-menu .nav-con .nav-item.home .drop {
                    vertical-align: top;
                    color: #a1a1a1;
                    display: inline-block;
                    transform: rotate(180deg);
                    transition: transform 0.3s;
                }

                .stardust-video .nav-menu .nav-con .nav-item.home:hover .drop {
                    transform: rotate(0deg);
                }

                .stardust-video .nav-menu .nav-con .nav-item.home .channel-menu {
                    left: -62px;
                }

                .stardust-video .nav-menu .nav-con .nav-item .i-frame {
                    top: 50px;
                }

                .stardust-video .nav-menu .nav-con .nav-item .app-orcode-box {
                    top: 50px;
                }

                .stardust-video .nav-menu .up-load {
                    height: 54px;
                }

                .stardust-video .nav-menu .up-load .u-link {
                    height: 54px;
                    line-height: 48px;
                }

                .stardust-video .nav-menu .up-load .up-nav {
                    top: 50px;
                }

                .stardust-video .head-banner {
                    margin-top: -50px;
                }

                .stardust-video .mini-wnd-nav {
                    top: 50px;
                }

                .stardust-video .profile-m {
                    top: 50px !important;
                }

                .stardust-video .nav-search-box {
                    margin: 9px 10px 0 15px;
                }

                .stardust-video .nav-search-box .nav-search .nav-search-keyword {
                    height: 32px;
                    line-height: 32px;
                }

                .stardust-video .nav-search-box .nav-search .nav-search-submit {
                    top: 7px;
                }

                .stardust-video .btn-search {
                    margin-top: 5px;
                }

                .svg-icon {
                    width: 1.8em;
                    height: 1.8em;
                    vertical-align: bottom;
                    fill: currentColor;
                    overflow: hidden;
                }
            </style>

            <style type="text/css">
                li[data-v-4d9bc88b] {
                    list-style: none;
                    color: #222;
                }

                a[data-v-4d9bc88b] {
                    text-decoration: none;
                    -webkit-transition: color 0.2s;
                    transition: color 0.2s;
                }

                .nav-item[data-v-4d9bc88b] {
                    float: left;
                    text-align: center;
                    line-height: 42px;
                    height: 42px;
                    position: relative;
                    background-color: rgba(255, 255, 255, 0);
                    -webkit-transition: all 0.3s;
                    transition: all 0.3s;
                }

                .nav-item[data-v-4d9bc88b]:hover {
                    background-color: rgba(255, 255, 255, 0.3);
                }

                .t[data-v-4d9bc88b] {
                    color: inherit;
                    height: 100%;
                    display: block;
                    padding: 0 11px;
                }

                .num[data-v-4d9bc88b] {
                    height: 12px;
                    line-height: 12px;
                    color: #FFF;
                    background-color: #F25D8E;
                    border-radius: 10px;
                    position: absolute;
                    padding: 1px 2px;
                    font-size: 12px;
                    top: 1px;
                    right: -4px;
                    min-width: 16px;
                    z-index: 30;
                    text-align: center;
                }

                .red_point[data-v-4d9bc88b] {
                    height: 8px;
                    width: 8px;
                    border-radius: 100%;
                    position: absolute;
                    right: 6px;
                    top: 7px;
                    background-color: #F25D8E;
                }

                .notify-float[data-v-4d9bc88b] {
                    /*border: 1px solid #F25D8E;*/
                    -webkit-box-shadow: 0 1px 4px 0 #f25d8e;
                    box-shadow: 0 1px 4px 0 #f25d8e;
                    background: #FFF;
                    position: absolute;
                    border-radius: 4px;
                    line-height: 36px;
                    text-align: left;
                    padding: 0px 15px;
                    top: 52px;
                    left: -8px;
                    white-space: nowrap;
                }

                .notify-float .tri[data-v-4d9bc88b] {
                    width: 12px;
                    height: 12px;
                    position: absolute;
                    top: -6px;
                    background-color: white;
                    left: 22px;
                    -webkit-transform: rotate(45deg);
                    transform: rotate(45deg);
                }

                .notify-float .float_msg>div[data-v-4d9bc88b] {
                    display: inline-block;
                    margin-right: 30px;
                }

                .notify-float .float_msg>div span[data-v-4d9bc88b] {
                    cursor: pointer;
                    color: #00A1D6;
                }

                .notify-float .float_msg>div span[data-v-4d9bc88b]:hover {
                    color: #F25D8E;
                }

                .notify-float .float_msg>i[data-v-4d9bc88b] {
                    float: none;
                    cursor: pointer;
                    background-position: -472px -536px;
                    width: 16px;
                    height: 16px;
                }

                .b-icon[data-v-4d9bc88b] {
                    display: inline-block;
                    vertical-align: middle;
                    width: 12px;
                    height: 12px;
                    background: url(//static.hdslb.com/images/base/icons.png) no-repeat;
                }

                .slide-fade-enter-active[data-v-4d9bc88b],
                .slide-fade-leave-active[data-v-4d9bc88b] {
                    -webkit-transition: all 0.3s;
                    transition: all 0.3s;
                }

                .slide-fade-enter[data-v-4d9bc88b],
                .slide-fade-leave-to[data-v-4d9bc88b] {
                    -webkit-transform: translateY(5px);
                    transform: translateY(5px);
                    opacity: 0;
                }

                .i-frame[data-v-4d9bc88b] {
                    position: absolute;
                    width: 110px;
                    height: 210px;
                    top: 100% !important;
                    left: 0 !important;
                    left: calc(50% - 55px) !important;
                    background: #FFF;
                    -webkit-box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    border-radius: 0 0 4px 4px;
                    overflow: hidden;
                }
            </style>

            <style type="text/css">
                li[data-v-637a89c0] {
                    list-style: none;
                    color: #222;
                }

                a[data-v-637a89c0] {
                    text-decoration: none;
                    -webkit-transition: color .2s;
                    transition: color .2s;
                }

                .nav-item[data-v-637a89c0] {
                    float: left;
                    text-align: center;
                    line-height: 42px;
                    height: 42px;
                    position: relative;
                    background-color: rgba(255, 255, 255, 0);
                    -webkit-transition: all .3s;
                    transition: all .3s;
                }

                .nav-item[data-v-637a89c0]:hover {
                    background-color: rgba(255, 255, 255, 0.3);
                }

                .t[data-v-637a89c0] {
                    color: inherit;
                    height: 100%;
                    display: block;
                    padding: 0 11px;
                }

                .bp-red-point[data-v-637a89c0] {
                    height: 8px;
                    width: 8px;
                    border-radius: 100%;
                    position: absolute;
                    right: 4px;
                    top: 7px;
                    background-color: #F25D8E;
                }

                .num[data-v-637a89c0] {
                    height: 12px;
                    line-height: 12px;
                    color: #FFF;
                    background-color: #F25D8E;
                    border-radius: 10px;
                    position: absolute;
                    padding: 1px 2px;
                    font-size: 12px;
                    top: 1px;
                    right: -4px;
                    min-width: 16px;
                    z-index: 30;
                    text-align: center;
                }

                .slide-fade-enter-active[data-v-637a89c0],
                .slide-fade-leave-active[data-v-637a89c0] {
                    -webkit-transition: all .3s;
                    transition: all .3s;
                }

                .slide-fade-enter[data-v-637a89c0],
                .slide-fade-leave-to[data-v-637a89c0] {
                    -webkit-transform: translateY(5px);
                    transform: translateY(5px);
                    opacity: 0;
                }

                .i-frame[data-v-637a89c0] {
                    position: absolute;
                    width: 380px;
                    height: 422px;
                    top: 100% !important;
                    left: 0 !important;
                    left: calc(50% - 190px) !important;
                    background: transparent;
                    /*box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;*/
                    border-radius: 0 0 4px 4px;
                    overflow: hidden;
                }

                .i-frame iframe[data-v-637a89c0] {
                    overflow: hidden;
                    width: 380px;
                    height: 422px;
                    /*padding: 0 10px 10px;*/
                    background: transparent;
                }
            </style>

            <style type="text/css">
                li[data-v-4d9bc88b] {
                    list-style: none;
                    color: #222;
                }

                a[data-v-4d9bc88b] {
                    text-decoration: none;
                    -webkit-transition: color 0.2s;
                    transition: color 0.2s;
                }

                .nav-item[data-v-4d9bc88b] {
                    float: left;
                    text-align: center;
                    line-height: 42px;
                    height: 42px;
                    position: relative;
                    background-color: rgba(255, 255, 255, 0);
                    -webkit-transition: all 0.3s;
                    transition: all 0.3s;
                }

                .nav-item[data-v-4d9bc88b]:hover {
                    background-color: rgba(255, 255, 255, 0.3);
                }

                .t[data-v-4d9bc88b] {
                    color: inherit;
                    height: 100%;
                    display: block;
                    padding: 0 11px;
                }

                .num[data-v-4d9bc88b] {
                    height: 12px;
                    line-height: 12px;
                    color: #FFF;
                    background-color: #F25D8E;
                    border-radius: 10px;
                    position: absolute;
                    padding: 1px 2px;
                    font-size: 12px;
                    top: 1px;
                    right: -4px;
                    min-width: 16px;
                    z-index: 30;
                    text-align: center;
                }

                .red_point[data-v-4d9bc88b] {
                    height: 8px;
                    width: 8px;
                    border-radius: 100%;
                    position: absolute;
                    right: 6px;
                    top: 7px;
                    background-color: #F25D8E;
                }

                .notify-float[data-v-4d9bc88b] {
                    /*border: 1px solid #F25D8E;*/
                    -webkit-box-shadow: 0 1px 4px 0 #f25d8e;
                    box-shadow: 0 1px 4px 0 #f25d8e;
                    background: #FFF;
                    position: absolute;
                    border-radius: 4px;
                    line-height: 36px;
                    text-align: left;
                    padding: 0px 15px;
                    top: 52px;
                    left: -8px;
                    white-space: nowrap;
                }

                .notify-float .tri[data-v-4d9bc88b] {
                    width: 12px;
                    height: 12px;
                    position: absolute;
                    top: -6px;
                    background-color: white;
                    left: 22px;
                    -webkit-transform: rotate(45deg);
                    transform: rotate(45deg);
                }

                .notify-float .float_msg>div[data-v-4d9bc88b] {
                    display: inline-block;
                    margin-right: 30px;
                }

                .notify-float .float_msg>div span[data-v-4d9bc88b] {
                    cursor: pointer;
                    color: #00A1D6;
                }

                .notify-float .float_msg>div span[data-v-4d9bc88b]:hover {
                    color: #F25D8E;
                }

                .notify-float .float_msg>i[data-v-4d9bc88b] {
                    float: none;
                    cursor: pointer;
                    background-position: -472px -536px;
                    width: 16px;
                    height: 16px;
                }

                .b-icon[data-v-4d9bc88b] {
                    display: inline-block;
                    vertical-align: middle;
                    width: 12px;
                    height: 12px;
                    background: url(//static.hdslb.com/images/base/icons.png) no-repeat;
                }

                .slide-fade-enter-active[data-v-4d9bc88b],
                .slide-fade-leave-active[data-v-4d9bc88b] {
                    -webkit-transition: all 0.3s;
                    transition: all 0.3s;
                }

                .slide-fade-enter[data-v-4d9bc88b],
                .slide-fade-leave-to[data-v-4d9bc88b] {
                    -webkit-transform: translateY(5px);
                    transform: translateY(5px);
                    opacity: 0;
                }

                .i-frame[data-v-4d9bc88b] {
                    position: absolute;
                    width: 110px;
                    height: 210px;
                    top: 100% !important;
                    left: 0 !important;
                    left: calc(50% - 55px) !important;
                    background: #FFF;
                    -webkit-box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px;
                    border-radius: 0 0 4px 4px;
                    overflow: hidden;
                }
            </style>
		<meta charset="utf-8">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta name="spm_prefix" content="333.22">
		<title>投稿 - 噼哩噼哩~-pilipili</title>
		<link rel="shortcut icon" href="./img/peach.ico" />
		<link rel="icon" href="https://s1.hdslb.com/bfs/studio/common/images/favicon.ico" type="image/x-icon">
		<style>@keyframes rotate{100%{transform:rotate(360deg)}}.skeleton-container{text-align:center}.skeleton-content{line-height:38px;font-size:14px}.skeleton-content>h1{font-size:20px}.skeleton-content>i.skeleton-loading{display:block;width:60px;height:60px;border-radius:50%;margin:80px auto;animation:rotate .8s infinite linear;border:3px solid #cfd8e0;border-right-color:transparent}</style>
		<link href="//s2.hdslb.com/bfs/static/studio-upload-v3/static/css/app.f1a288744d4f1cd9b31dad898ecdae03.css" rel="stylesheet">
		<link rel="preload" href="//s2.hdslb.com/bfs/static/studio-upload-v3/static/js/manifest.8e9d20b647ef6f79e446.js" as="script"
		 crossorigin="anonymous">
		<link rel="preload" href="//s2.hdslb.com/bfs/static/studio-upload-v3/static/js/vendor.041dbb2283e2efbb4b46.js" as="script"
		 crossorigin="anonymous">
		<link rel="preload" href="//s2.hdslb.com/bfs/static/studio-upload-v3/static/js/app.65abc689a434a302bb1a.js" as="script"
		 crossorigin="anonymous">
		<script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="//s2.hdslb.com/bfs/static/studio-upload-v3/static/js/0.ef6f7a7725de212d9d2c.js"></script>
		<script type="text/javascript" charset="utf-8" async="" crossorigin="anonymous" src="//s2.hdslb.com/bfs/static/studio-upload-v3/static/js/1.3b707a0c6eb7c26287ec.js"></script>
	</head>
	<body>
    <div id="bili-header-m" class="bili-header-m report-wrap-module stardust-common">
        <div class="nav-menu">
            <!---->
            <div class="nav-mask"></div>
            <div class="nav-wrapper bili-wrapper">
                <div class="nav-con nav-wrapper-left">
                    <ul class="nav-con-ul">
                        <li report-id="playpage_main" class="nav-item home"><a href="index.php" title="主站" class="t" style="margin-right: 270px"><i class="header-iconfont header-icon-bilibili-tv"></i>
                                主站
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="nav-wrapper-right">
                    <!---->
                    <div class="nav-con">
                        <ul class="nav-con-ul">
                            <li report-id="big_tab_click" class="nav-item"><a style="cursor:default;margin-right: 200px;"
                                                                              class="t">

                                    <!----></a>
                            </li>
                            <li report-id="playpage_account" class="nav-item profile-info"><a href="center.php"
                                                                                              class="t">
                                    <div class="i-face scale-in"><img src="<?php echo $img; ?>"
                                                                      class="face"></div>
                                </a>

                            </li>

                            <li report-id="playpage_collection" class="nav-item"><a href="logout.php" title="退出登录"
                                                                                    class="t">退出登录</a>
                                <!---->
                            </li>
                        </ul>
                    </div>
                    <div report-id="playpage_contribution" class="up-load"><a href="upload.php"
                                                                              target="_blank" class="u-link">
                            投稿
                        </a>
                        <!---->
                    </div>
                </div>
            </div>
        </div>
        <!---->
        <!---->
    </div>

    <form action="vedioOP.php" method="post" enctype="multipart/form-data">
		<div data-v-6d04a0e9="" id="app" class="canary-container">
			<div data-v-01cfd5ed="" data-v-6d04a0e9="" class="notify-v2-container">
				<!---->
			</div>
			<!---->
			<div data-v-6ec1eb48="" data-v-6d04a0e9="" class="upload-v2-container">
				<div data-v-7d11eb07="" data-v-6ec1eb48="" class="upload-v2-step2-container" style="">
					<!---->
					<div data-v-75f0b584="" data-v-7d11eb07="" class="file-list-v2-container">
						<div data-v-75f0b584="" class="file-title">
							<h1 data-v-75f0b584="">文件上传</h1>
							<p data-v-75f0b584="">（单次最多允许上传100p视频，推荐采用mp4、flv格式，可有效缩短审核转码耗时）</p>
						</div>
						<div data-v-640a3622="" class="ui-v2-normal-line-white-divide"></div>
						<div data-v-75f0b584="" class="file-add-btn-group">
							<div data-v-75f0b584="" class="file-add-btn">
								<img data-v-75f0b584="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAPhJREFUSA3tVm0KwjAMXf1A2BFkehvv4gU8xfyxn97F66h4ABFEZn0ZKdTClqZD2I8GQrMmL699Y2FFMXWz1i7hR3hN8d/PC5It/M2+0RIutADUG/iLcTMtXg3QEoT1mTBUZPRzlnS0hGGDFElbr4kfe9v9YffhY2rMUbKG00ctWYUCV0dTJ+bQFpibMabtgADV2Nh7jRD2GmFKzj6xUjPJqOYEwkPM6aRmqry7oVbSM7PssF4iGOmGV9zwE1H7WwL5K/iDnd6nylIkJTWc+bHbG1xTCAcbSslMKCmkzmdJ1ZJJgJS/NpoWK26snhwphHeQNUxI8bTtC6n0ShyL6cu0AAAAAElFTkSuQmCC"
								 alt="icon_add" class="file-add-btn-img"> 
								 <span data-v-75f0b584="" class="file-add-btn-title" id="video">添加视频</span>
								<div data-v-75f0b584="" id="bili-upload-btn-more">
                                    <input id="video" type="file" name="video" style="opacity: 0;height: 100%;width: 100%;" onchange="loadF_name(this)"/>
                                    <input data-v-75f0b584="" type="hidden" name="MAX_FILE_SIZE" value="10485760">

                                </div>
							</div>
                            <span id="file_name" style="font-size: 18px;margin-left: 20px">尚未添加视频(°ー°〃)</span>
						</div>
						<div data-v-75f0b584="" class="dividing-line"></div>
					</div>
					<div data-v-3e9c20f4="" data-v-7d11eb07="" class="file-content-v2-container">
						<div data-v-640a3622="" data-v-3e9c20f4="" class="normal-v2-container">
							<div data-v-640a3622="" class="normal-title-wrp">
								<h1 data-v-640a3622="">基本信息</h1>
							</div>
							<div data-v-7484fabe="" data-v-640a3622="" class="cover-v2-container">
								<div data-v-704ae438="" data-v-7484fabe="" class="section-title-v2-container">
									<!---->
									<h3 data-v-704ae438="" class="section-title-v2-content-main">视频封面设置</h3>
									<p data-v-704ae438="" class="section-title-v2-content-sub">（格式jpeg、png，文件大小≤5MB，建议尺寸≥1146*717，最低尺寸≥960*600）</p>
									<!---->
									<!---->
								</div>
								<div data-v-7484fabe="" class="cover-v2-detail-wrp">
									<div data-v-7484fabe="" class="cover-v2-preview">
										<div data-v-7484fabe="" class="cover-v2-preview-default">
											<img data-v-7484fabe="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAACk9JREFUeAHtWw9QVMcZ39337gCpipJUiBmpVE1jEkyTdrSdtqmYZpKBTjNtPNA6wBn1OKGkZdp0pv+CZjqZDpEkVOAuEv4VEC5Tm3a0SdXWJq0zbVInNR1JtamiNaIWC6aGv3dv+9sHD+4d73HvkHM47A7v3u737X77fd9+++23uw9CbvJEY1n+5/e0LoqT5LuoRPrpQM9fXC7XcKTysEgbzJT6nsb2TfF2+RiTyW8pJUd5/IJ9lXW+WyPlLyYV4G3yfQ5Ce/AsHhWYIp9tl/mzKEdk1TGngN2Njcmc8BrImRg62pTT7Mo9zZpSQtGG5VhTAJVJfDkl9G4jaTgldmaX5xjhzGAxpQBPQ1sBbN1pJgxs/0S30n/ODG8EtzxfhOnJPC4LDCzDLLtKFP6KqyD3n0ZEowGrbmzNkIh8BH0vNKLPCVYCzrNc+TlHjPBmMEsK8NS3LCeSvE9vevwS5/SZvivkxdJSR79ZB9MBLy9vSpz70fhDcHSfMaOnEPIDd57jx2Z4M7ilKUAl2a0XXpCji8DQ83OS+e9q6nyZZh1MBxzC75xMeM75r4d7L4oVIOJkSQEY6XQzypgSa7AWv+pp8nl317akmdWbKtzT1PZVCP/EJO3Pc0UpKikpGZykjinKkgLAgGxKYQRhx1zaZrPZ3qhpat9aVuazh6lvCV1d15JOCXsBlSWTBgES4N9wOzd0muDDgi0pQOHktbCURAVKljBCX0xJJ69W1e39rKU2JpUqKyvjmGyrAvp2kyqEc1Lhcua8Yoa3ArekgGuXB+oJJwetEBR1YA2ZsiQd8jT6dk0lPBU07Ekp3wWdh0XeMHHyR8T/ZYa4CICWVgFBb9QTu5AtxZSIJNp6Dx5656XTHS1lZWXIhk+ehr3rKGX7CaXxxrV597AS+GJxwcYTxnjrUMsK0EgKRyfb5CfBnBONEzS4hfeBgEKe2l7gODZZXa/3Z6kk3v570F9hUg9On+cV5uc0m+AjAkesAI16VX3bpyXGfgRreAQwMyelVVffCFaugfnK/mG6q3SL4z86JArr1/ukddmkBTRzQnFamSvcU1iQ49bK1/sOq4CKCl+CPHcoGWG2TetMlgOcMGmYcSWeMLYezujbYDpZw4d7QxEdEGQH4cqbfr+k8iBoMol9DR7EdD1Hu9OcBx4jCunR2hn1pfI3MNx36dLp7nDTzlABYiTWZisPSYRtQKdr4NXmUz5xKQQO+w+O9ZcmoU5EmxCVcU7GrEDQwt8CxBXmjpmTPrT7EI8Fi+MDnNAL2DkepAHaUrjZ0WGkrAkKqKr1LZPsvAKR35eNGsQkjJNejNRzQ70XfxIaMOkUMLLhkPbBAX08JgUNwzT8T3PfFboteO8yZm7ifE0iUttsFV7oBtNrU+ItXLdhGlNAvF36PmrcGUaJsY/mpLi6yfeAJoga4/90j28pvHieBgx+wzMdogpHUEKuKgpqxUBiDMY+4pizwPCXdCxTapMI/yZgb+CBa0CqaWxzMco8Iq9LCt/V1fnuk+GWEl2bGVQA3yxl6cpyDFupji2sPoNDQ6tKtm46r04BbGA+qaswUjhLBunTsSq8EEHw3q98+DQW2HM6+XCqJMfZVUevKkA1F10NdVE+5XI5roaAY674LadTLIEnQxlnRFEDN1UBMBH1HVIpEFKO2SKCOP8E5jlTZTYSfELdWAfAAkyd902hgMkGMNxR12RtdTjcyNxuk+wrKOOrEc3fj3UoAU+duyDn57qKERTEnuTBLLKNU/4VTNN+LMnvYuE6ThXSQYb8XS7Xxu4IyBlWnZICxOHIvFvi0xWqZCC6Wo3nfnja5TA0XE6OWJsaMVDykKex7bHC/NxfGvYeBgjhH4Z3qtYsGJQfFeS5RPw0QX4fF6Rn0fcJhSvHsZKdUvC48x3vhyGrQ1tWgBiNzCwlF5u1RyHcvRiNxYyw8QMRg1kGEOjTYvQ4JQVg7i4zICt0IPhOg/BpeH8BMYwQijNOenA6/Yuh3qHSkpJNHwhguGRZAeuyle0QvlIjaMSYhtO9KV2EsqgOnUWcLGx7x2gKQ1mIjh6Pm2/7F6A7xjCTZCw7QayU4uQn4oSg9AIaTUV44uf+36DlvyPuFBZqtY1lBeBg4b9WiYp6kPgafl6nCv1OJO2C64pDT7+iZOH8uxEO9W3w0AOFhj1YRd/i0MRSsjwFYF5HQNFhQFUETF1g7DzMr4NQ/jdElqewgTp5+ADrfPllx3UFVEXO3LdAv0DcE9DEW5Mlm7RcUsgdmPAZUPA9wC1Bv4uxk9WO7IZwZHbAgE9DkGUF0P7el0h80iJoNxNTuhuj8XdMundw0nuSDQxccLvzLhv2ME3A0ZMcMZ3E87pGVtxaM2JbzLh8JwbhNsDfxNJ7VMOHe1tWwOgHSDuwwZhRG6Ti/PwrEFI874QT1ghv2QdojWN5d6jJEPyOWAHBjWdD/v8KmA2jeD0yWHaCU+iE1jS0bUSYmofviWpCr7FrGtodlNEt+K7naNcZ+kxZmWMouA98EOXErZMTFy9XeIB6C50Oa1f0wUQs5KOmAK+3NRkClIOHVC5REZqO3ePDkTLGqDinW431OzMlbbgV+X/gUZPX67URpu4h7lOjaIkkAhEVBUTVB2BdVk9iEKhkPldfnzQqH0lNXTkXee2KXaJM1n1M0SvLuBan43eNnF/3tlfrO/QdNQUcPiz3IFA6Pdrh0gQ2p6K6umWBuGzFScH3AA/68oOWVtX7UjTmkqSPPIX8Eq2MMFhEg1FJUZsCIgR+MLutmRD2gOAcW1cnS5TXJiaSAZQ+oZOGkgxJ4q95Gtrb4RfECfX6cTzvDvj9+8bL05uLmgIEm11nWFNqOl8HgXNFGUr4mHjrkrghVrexdBUOP1bpcCgg9P5h8Zavnw2FT1c5alNAMCg8+2DvsAu7uVo8GHld6sJ+wu0PBO6Fr6g2wJ9VFF5amJfj0bWa5kJULUDwOnoysxVzvIpJ5B6m8HmE8ct+P/9T0eYNYnUQqaimcW8tVaT74DAlzPkzfQFyrHRLztj3AyPVpv836grQWC5yOv6KvHgMkzt/w9tAiOeGpqhOgRsqyRQ7uykUgJsh+FLjNKIAToYN0JIBLBZBcCtEBF66hK9f1dBbVQAUJE5ZdAmtVni9vvk6YAwWdje0rsTFSkYw61h1xLmien+gKkDh9A/BFUbzaYjYdopLEANcLIAohL9LplItItJ5OoYp7ZQGyXsCJsyDVFY2z8NZ+luIVFaIcnCCdRwHgVNYmm7YihHc/xTzOJcV/1nCsayGCA+CsIBn8aWpelqtKkB04mnwPY4LltopdhhLzbrA7BpXnuOcYHrECSJzsbOjEaPdJICzNWEp8MOSSzThhZxjFiAK2IfP4QlJNTCbPFGeTQmD+wEOVp5wOx0NwXLplrr9+/cPf2rV3b9KTEqGmdA7cAk6vicPbhVDeTHqYPcg/u1ns7vAMeHCRGcBwXJV1PoWJsh8LXZwn4ciboPp2IPxMz5P+TUEQCcDCj+03Zn7Z/BrGgzNeFmiyeD/AHZMPYrjJkj7AAAAAElFTkSuQmCC"
											 alt="bili_tv" class="bili_tv">
											 <span data-v-7484fabe="" class="cover-v2-upload-tip" id="cover">上传封面</span>
											 </div>
										<input data-v-7484fabe=""  id="cover-img" type="file" name="cover" size="50" onchange="document.getElementById('cover').innerHTML='重新上传';loadImg();">


									</div>
                                    <img id="show-img" style="width: 200px;height: 125px;margin-right: 350px;"  >
								</div>


							</div>
							<div data-v-640a3622="" class="ui-v2-normal-line-white-divide"></div>
							<div data-v-b3b70444="" data-v-640a3622="" class="content-title-v2-container">
								<div data-v-704ae438="" data-v-b3b70444="" class="section-title-v2-container">
									<p data-v-704ae438="" class="section-title-v2-deg">*</p>
									<h3 data-v-704ae438="" class="section-title-v2-content-main">标题</h3>
								</div>
								<div data-v-b3b70444="" class="content-title-v2-input-wrp">
									<div data-v-4550f808="" data-v-b3b70444="" class="input-box-v2-1-container">
										<div data-v-4550f808="" class="input-box-v2-1-instance">
                                            <input data-v-4550f808="" type="text" maxlength="20" name="title" placeholder="请输入稿件标题" class="input-box-v2-1-val"></div>
										<p data-v-4550f808="" class="input-box-v2-1-max-tip">20字内</p>
									</div>
								</div>
							</div>
							<div data-v-640a3622="" class="ui-v2-normal-line-white-divide"></div>
								<!---->
							</div>
							<div data-v-640a3622="" class="dividing-line"></div>
						</div>
						<div data-v-3dc14c40="" data-v-3e9c20f4="" class="submit-button-group-v2-container">
                            <span data-v-3dc14c40="" class="submit-btn-group-add"><input type="submit" style="color: #ffffff;height: 100%" value="立即投稿"></span>
                        </div>
					</div>
					<div data-v-51ea6eb8="" data-v-7d11eb07="" class="auto-complete-container-v2" style="display: none;">
					</div>
				</div>
			</div>
    </form>
	</body>
</html>


<?php


echo "<script>ShowFileName(f)</script>"

?>