<?php
@session_start();

include_once ("functions/database.php");
@get_connection();
$sql = "select * from video";
$result = mysqli_query($database_connection, $sql);
$i=0;
?>

<!DOCTYPE html>
<html lang="en">

<script src="./js/index.js"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>噼哩噼哩~-pilipili</title>
    <link rel="shortcut icon" href="./img/peach.ico" />
    <link rel="stylesheet" href="./css/reset.css">
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/header.css">
    <link rel="stylesheet" href="./css/summary.css">
    <link rel="stylesheet" href="./css/popularize.css">
    <link rel="stylesheet" href="./css/liveStrm.css">
    <link rel="stylesheet" href="./css/animate.css">
    <link rel="stylesheet" href="./css/fanju.css">
    <link rel="stylesheet" href="./css/fjDongTai.css">
    <link rel="stylesheet" href="./css/guoChuang.css">
    <link rel="stylesheet" href="./css/gcyc.css">
    <link rel="stylesheet" href="./css/music.css">
    <link rel="stylesheet" href="./css/talkMusic.css">
    <link rel="stylesheet" href="./css/tbtj.css">
    <link rel="stylesheet" href="./css/footer.css">
    <link rel="stylesheet" href="./css/siderBar.css">
    <link rel="stylesheet" href="./css/a1.css">
</head>
<body>
    <header>
        <div class="blurBg"></div>
        <nav>
            <div class="nav-wrapper">
                <ul>
                    <li>
                        <a href="index.php">主站</a>
                    </li>
                </ul>
                <div class="upUser">
                    <!--登录部分，遇到已经登录过的需要变成用户的头像-->
                    <!--且登录过的人需要把连接改为./center.html-->
                    <a id="log1" href="./login.html">
                        <img id="log2"  src="./img/akari.jpg" alt="">
                    </a>
                    <a style="display: none"> </a>
                    <span>
                        <a href="upload.php">投稿</a>
                    </span>
                </div>
            </div>
        </nav>
        <div class="header-content">
			<a href="index.php">
                <img src="./img/biliLogo.png" alt="">
            </a>
            <div class="rankAndSearch">
                <form action="search.php" method="post">
                    <input type="text" name="keyword" placeholder="搜索">
                    <input type="submit">
                </form>
            </div>
        </div>
    </header>
    <main style="width: 950px">
        <section  style="margin-top: 25px;width: 950px;margin-left: auto;margin-right: auto">
                <div class="sctnLft-header">
                    <div class="sctnLftHdr-left">
                        <span class="sctnLftHdrLft-icon anmtLftHdrLft-icon"></span>
                        <a class="sctnLftHdrLft-topic" style="cursor:default">特别推荐</a>
                    </div>
                </div>
                <div style="width: 1200px">
                    <table align="left">
                        <?php
                        echo"<tr>";
                        while(@$row=mysqli_fetch_array($result))
                        {
                            @$i++;
                            echo "<td style='padding: 10px 18px 10px 18px;'>
                                                            <a href='videoPlayer.php?av={$row['av_num']}'>
                                                             <img src='cover/cover/{$row['cover']}' width='180' height='100'>
                                                               </a>
                                                              <table style=\"border: solid 1px #b8b8b8\" width='180'>
                                                              <tr style='height: 1%'>
                                                              <td colspan='3' style='border: solid 1px #b8b8b8;border-bottom:transparent; '>
                                                              <a class='a1' href='videoPlayer.php?av={$row['av_num']}'><font size='2px'>{$row['title']}</font></a>
                                                              </td>
                                                              </tr>
                                                              <tr>
                                                              <td style='border: solid 1px #b8b8b8;border-bottom: transparent;border-top: transparent;border-right: transparent'>
                                                              <span style='font-size: 12px;color: gray;'>上传时间</span>
                                                              </td>
                                                               <td width='68%' style='border: solid 1px #b8b8b8;border-bottom: transparent;border-top: transparent;border-left: transparent' align='left'>
                                                               <span style='font-size: 12px;color: gray;'>{$row['send_time']}</span>
                                                               </td>
                                                               </tr>
                                                               <tr>
                                                               <td style='border: solid 1px #b8b8b8;border-bottom: transparent;border-top: transparent;border-right: transparent'>
                                                               <font size='2px' color='gray'>浏览量:</font>
                                                               </td>
                                                               <td style='border: solid 1px #b8b8b8;border-bottom: transparent;border-top: transparent;border-left: transparent' align='left'>
                                                               <font size='2px' color='gray'>{$row['view_count']}</font>
                                                               </td>
                                                               </tr>
                                                               </table>
                                                               </td>";
                            if($i%4==0)
                            {
                                echo"</tr>";
                                echo"<tr>";
                            }
                        }
                        echo"</tr>";
                        ?>
                    </table>
                </div>
        </section>
        </div>
    </main>

</body>
</html>

<?php

//开启数据库链接

@$acc=$_SESSION['acc_num'];
@$pas=$_SESSION['password'];

@$result = mysqli_query($database_connection,"SELECT * FROM user where acc_num='$acc' and password='$pas'");

while(@$row = mysqli_fetch_array($result)) {
    $user_id=$row['user_id'];
    $user_name=$row['user_name'];
    $sex=$row['sex'];
    $gt_num=$row['gt_num'];
    $img = $row['img'];
}


if(@$acc!=null && @$pas!=null && @$user_id==null){
    echo "<script>alert('账号或密码输入错误，请重新输入~');location.href='login.html'</script>";
}

else if ($acc!=null && $pas!=null && $user_id!=null){
    $_SESSION['user_id']=$user_id;
    @$img="'./img/".$img."'";

    echo "<script>ChangeFace(\"center.php\",$img);</script>";
}


//关闭数据库链接
close_connection();

?>
