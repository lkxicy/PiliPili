<?php
include_once("functions/database.php");
session_start();
get_connection();
$av=$_POST['av_n'];
$id=$_SESSION['user_id'];
$sql_find="select * from lk where lav_num={$av} and lu_id='$id' ";
$result_find=mysqli_query($database_connection,$sql_find);
$row_find=mysqli_fetch_array($result_find);
if(isset($row_find))
{
    $sql_unlike = "update video set t_count=t_count-1 where av_num={$av}";
    $sql_delete="delete from lk where lav_num={$av}";
    $result_unlike = mysqli_query($database_connection, $sql_unlike);
    $result_cancal=mysqli_query($database_connection,$sql_delete);
    echo "<script>alert('取消点赞');location.href='videoPlayer.php?av=$av'</script>";
}
else {
    $sql = "update video set t_count=t_count+1 where av_num={$av}";
    $sql_like = "insert into lk value ({$av},'$id')";
    $result = mysqli_query($database_connection, $sql);
    $result_like = mysqli_query($database_connection, $sql_like);
    echo "<script>alert('点赞成功！');location.href='videoPlayer.php?av=$av'</script>";
}
?>