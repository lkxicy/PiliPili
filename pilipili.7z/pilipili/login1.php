<?php
@session_start();

$acc_num=$_POST['acc_num'];
$password=$_POST['password'];

if($acc_num==null){
    echo "<script>alert('账号不可为空！');location.href='login.html'</script>";
}

else if($password==null){
    echo "<script>alert('密码不可为空！');location.href='login.html'</script>";
}

include 'index1.php';
SetID($acc_num,$password);

echo "<script>location.href='index.php'</script>";

?>
