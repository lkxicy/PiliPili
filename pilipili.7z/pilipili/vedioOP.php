<?php
session_start();
if(empty($_POST)){
    @$message = "上传的文件超过了php.ini中post_max_size选项限制的值";
}else{
    include_once("functions/file_system.php");
    @$user_id = $_SESSION['user_id'];
    @$title=$_POST['title'];
    @$view_count=0;
    @$t_count=0;
    @$currentDate =  date("Y-m-d H:i:s");
    @$video_name = $_FILES['video']['name'];
    @$cover_name = $_FILES['cover']['name'];
    @$msg=substr($_FILES['video']['type'],0,5);
    @$msg1=substr($_FILES['cover']['type'],0,5);
    @$message = upload($_FILES["video"],"/data/video");
    @$message1 = upload($_FILES["cover"],"/data/cover");
   if(@$msg=="video"&&$msg1=="image") {
        $sql = "insert into video values(null,'$user_id','$currentDate','$title','$view_count','$t_count','$video_name','$cover_name')";
        include_once("functions/database.php");
        get_connection();
        mysqli_query($database_connection, $sql);
        close_connection();
        echo "<script>alert('投稿成功');location.href='index.php'</script>";
    }
    else{
        echo "<script>alert('文件类型上传失败');location.href='index.php'</script>";
    }
}
?>
