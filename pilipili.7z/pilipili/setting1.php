<?php
@session_start();

//获取SEESION中用户ID
$user_id=$_SESSION['user_id'];

$user_name=$_POST['user_name'];
$sex=$_POST['sex'];
$img=$_POST['img'];

if($user_name==null){
    echo "<script>alert('用户名不可为空！');location.href='center.php'</script>";
}

else if($img==null){
    echo "<script>alert('头像不可为空！');location.href='center.php'</script>";
}

include 'database.php';
get_connection();

$result = mysqli_query($database_connection,"SELECT user_name,user_id FROM user");
while(@$row = mysqli_fetch_array($result)) {
    if(@$row['user_name']==$user_name && @$row['user_id']!=$user_id){
        echo "<script>alert('已存在相同用户名，请重新输入');location.href='center.php'</script>";
    }
}

mysqli_query($database_connection,"UPDATE user SET user_name='$user_name',sex='$sex',img='$img' WHERE user_id='$user_id'");

echo "<script>alert('修改成功！');location.href='center.php'</script>";

close_connection();

?>
