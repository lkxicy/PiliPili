<?php
    session_start();
    session_unset();
    session_destroy();
    echo "<script>alert('退出登录成功！');location.href='index.php'</script>";
?>