function ChangeFace(h,s){
    document.getElementById("log1").href = h;
    document.getElementById("log2").src = s;
}

