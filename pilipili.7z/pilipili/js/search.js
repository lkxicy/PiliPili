function ChangeFace(s){
    document.getElementById("face-pad").style.marginRight = "0px";
    document.getElementById("face").src = s;
    document.getElementById("logout").style = "";
    document.getElementById("link").href = "center.php";
}