function ChangeSex(sex) {
    if(sex=='男'){
        document.getElementById("h-gender").className="icon gender male";
    }
    else if(sex=='女'){
        document.getElementById("h-gender").className="icon gender female";
    }

}

function VideoShow() {
    document.getElementById("video1").style.display="";
}