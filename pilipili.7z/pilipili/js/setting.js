var sum=0;

function SelectFace(obj) {

    console.log(obj.style.border);

    if (obj.style.border=="solid red") {
        obj.style.border="white";
        sum--;
    }
    else if(obj.style.border=="white"){
        sum++;
        if(sum>=2){
            alert("只能选择一个头像哦~");
            sum--;
        }
        else {
            document.getElementById("set1").value=obj.id;
            obj.style.border="solid red";

        }
    }
}