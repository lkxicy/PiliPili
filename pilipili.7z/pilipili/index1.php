<?php

function SetID($acc,$pas){
    $_SESSION['acc_num']=$acc;
    $_SESSION['password']=$pas;
}

?>



